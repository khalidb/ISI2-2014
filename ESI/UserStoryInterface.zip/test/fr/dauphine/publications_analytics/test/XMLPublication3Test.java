package fr.dauphine.publications_analytics.test;
import static org.junit.Assert.*;

import java.util.Scanner;

import javax.swing.JFrame;

import org.junit.Test;

import fr.dauphine.publications_analytics.src.Window;
import fr.dauphine.publications_analytics.src.XMLPublication3;
public class XMLPublication3Test {
	/*@Test
	//getCoAuthors(String file_name, String authorName, String typeDocument)
	public void Q1() throws Exception { //average
		//String file_name = "dblp_curated_sample.xml";
		Scanner sc = new Scanner(System.in);
		System.out.println("Please, select an author");
		String authorName = sc.nextLine();
		XMLPublication3 xb = new XMLPublication3();
		assertNull(xb.getCoAuthors("", authorName, "", "", ""));
	}
	
	@Test
	public void Q2Date() throws Exception { //average
		//String file_name = "dblp_curated_sample.xml";
		Scanner sc = new Scanner(System.in);
		System.out.println("Please, select an author");
		String authorName = sc.nextLine();
		System.out.println("Please, select an year");
		String year = sc.nextLine();
		XMLPublication3 xb = new XMLPublication3();
		assertNotNull(xb.getCoAuthors("", authorName, "", year, ""));
	}
	@Test
	public void Q2Range() throws Exception { //average
		//String file_name = "dblp_curated_sample.xml";
		Scanner sc = new Scanner(System.in);
		System.out.println("Please, select an author");
		String authorName = sc.nextLine();
		System.out.println("Please, select an beginning year");
		String startYear = sc.nextLine();
		System.out.println("Please, select an end year");
		String endYear = sc.nextLine();
		XMLPublication3 xb = new XMLPublication3();
		assertNotNull(xb.getCoAuthors("", authorName, "", startYear, endYear));
	}*/
	@Test
	public void Q3() throws Exception { //average
		
		
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Please, select an author");
		String authorName = sc.nextLine();
		System.out.println("Please, select a beginning year");
		String startYear = sc.nextLine();
		System.out.println("Please, select an end year");
		String endYear = sc.nextLine();
		System.out.println("Please, select a document type");
		String documentType = sc.nextLine();
		XMLPublication3 xb = new XMLPublication3();
		assertNotNull(xb.getCoAuthors("", authorName, documentType, startYear, endYear));*/
	}
	/*
	@Test
	public void Q4() throws Exception { //average
		Scanner sc = new Scanner(System.in);
		System.out.println("Please, select an author");
		String authorName = sc.nextLine();
		System.out.println("Please, select a beginning year");
		String startYear = sc.nextLine();
		System.out.println("Please, select an end year");
		String endYear = sc.nextLine();
		System.out.println("Please, select a document type");
		String documentType = sc.nextLine();
		System.out.println("Please, select an XML file");
		String file_name = sc.nextLine();
		XMLPublication3 xb = new XMLPublication3();
		assertNotNull(xb.getCoAuthors(file_name, authorName, documentType, startYear, endYear));
	}*/
}
