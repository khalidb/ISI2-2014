package fr.dauphine.publications_analytics.test;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.dauphine.publications_analytics.src.XMLPublication;



public class XMLPublicationTest {

	
	/*

	@Test
	public void should_support_one_publication() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publicationsA(file_name));
		
	}


	@Test
	public void sould_support_multiple_publications() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publicationsB(file_name));
		
	}
	

	@Test
	public void should_support_two_author_appearances() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_author_appearancesA(file_name));
		
	}
	
	
	@Test
	public void should_support_seven_author_appearances() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_author_appearancesB(file_name));
		
	}
	
	@Test
	public void should_have_two_as_a_mean() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.0;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_mean_number_of_authors_per_publicationA(file_name));
		
	}
	
	@Test
	public void should_have_two_thirtythree_as_mean() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_mean_number_of_authors_per_publicationC(file_name));
		
	}
	
	//------------1--------------------------------
	 @Test
	public void publication() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publicationC(file_name));
		
	}
	@Test
	public void author() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_auteurC(file_name));
		
	}
	@Test
	public void conference() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_conferenceC(file_name));
		
	}
	@Test
	public void article() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_articleC(file_name));
		
	}
	@Test
	public void book() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_bookC(file_name));
		
	}
	@Test
	public void bookParChapitre() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_book_chapterC(file_name));
	}
	
	//----------2----------------
	  
	@Test
	public void publicationParAuteur() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publication_par_authorC(file_name,xb.get_authorC(file_name)));
	}
	
	@Test
	public void conferenceParAuteur() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_conference_par_authorC(file_name,xb.get_authorC(file_name)));
	}
	
	@Test
	public void articleParAuteur() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_article_par_authorC(file_name,xb.get_authorC(file_name)));
	}
	@Test
	public void bookParAuteur() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_book_par_authorC(file_name,xb.get_authorC(file_name)));
	}
	@Test
	public void chapitreParAuteur() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_chapitre_par_authorC(file_name,xb.get_authorC(file_name)));
	}
	
	//----------3--------------
	 
	@Test
	public void publicationParYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publication_par_yearC(file_name,xb.get_yearC(file_name)));
	}
	@Test
	public void conferenceParYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_conference_par_yearC(file_name,xb.get_yearC(file_name)));
	}
	@Test
	public void articleParYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_article_par_yearC(file_name,xb.get_yearC(file_name)));
	}
	
	@Test
	public void bookParYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_book_par_yearC(file_name,xb.get_yearC(file_name)));
	}
	@Test
	public void chapitreParYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_chapitre_par_yearC(file_name,xb.get_yearC(file_name)));
	}
	@Test
	
	//-------4-------------
	 
	public void publicationInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_publication_in_each_yearC(file_name,xb.get_yearC(file_name),xb.get_authorC(file_name)));
	}   	
	@Test
	public void confInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_conference_in_each_yearC(file_name,xb.get_yearC(file_name),xb.get_authorC(file_name)));
	}
	@Test
	public void articleInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_article_in_each_yearC(file_name,xb.get_yearC(file_name),xb.get_authorC(file_name)));
	}
	@Test
	public void bookInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_book_in_each_yearC(file_name,xb.get_yearC(file_name),xb.get_authorC(file_name)));
	}
	@Test
	public void chapitreInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_chapitre_in_each_yearC(file_name,xb.get_yearC(file_name),xb.get_authorC(file_name)));
	}
	
*/
	@Test
	public void chapitreInEachYear() throws Exception {
		String file_name = "dblp_curated_sample.xml";
		double delta = 0.004;
		XMLPublication xb = new XMLPublication();
		assertNotNull(xb.get_number_of_article_in_each_yearC(file_name,xb.get_yearC(file_name)));
	}
}          	
           		
           		           		           		