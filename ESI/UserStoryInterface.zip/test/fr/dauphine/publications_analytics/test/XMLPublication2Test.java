package fr.dauphine.publications_analytics.test;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.dauphine.publications_analytics.src.XMLPublication;
import fr.dauphine.publications_analytics.src.XMLPublication2;

public class XMLPublication2Test {
	//Segolene
	/*
	@Test
	public void userStory2_a1() throws Exception { //average
		String file_name = "dblp_1.xml";
		//String file_name = "dblp_curated_sample.xml";
		XMLPublication2 xb = new XMLPublication2();
		assertNotNull(xb.averageNumberOfPublicationsForAnAuthor(file_name));
	}
	
	//Rachelle
	@Test
	public void userStory2_a2() throws Exception { //median
		String file_name = "dblp_1.xml";
		//String file_name = "dblp_curated_sample.xml";
		XMLPublication2 xb = new XMLPublication2();
		assertNotNull(xb.medianNumberOfPublicationsForAnAuthor(file_name));
	}
	
	//Rachelle
	@Test
	public void userStory2_a3() throws Exception { //mode
		String file_name = "dblp_1.xml";
		//String file_name = "dblp_curated_sample.xml";
		XMLPublication2 xb = new XMLPublication2();
		assertNotNull(xb.modeNumberOfPublicationsForAnAuthor(file_name));
	}
	
	//S�gol�ne
	@Test
	public void userStory1(){
		System.out.println("\nUSER STORY 1\n");
		XMLPublication2 xb = new XMLPublication2();
		System.out.println("1.a");
		assertEquals(0,xb.averageMedianAndMean("dblp_curated_sample.xml","publications"));
		System.out.println("1.b");
		assertEquals(0,xb.averageMedianAndMean("dblp_curated_sample.xml","journalArticles"));
		System.out.println("1.c");
		assertEquals(0,xb.averageMedianAndMean("dblp_curated_sample.xml","conferenceProceedings"));
		System.out.println("1.d");
		assertEquals(0,xb.averageMedianAndMean("dblp_curated_sample.xml","bookChapters"));
		System.out.println("1.e");
		assertEquals(0,xb.averageMedianAndMean("dblp_curated_sample.xml","books"));
	}
	
	@Test
	public void userStory2(){
		/*System.out.println("\nUSER STORY 2\n");
		XMLPublication2 xb = new XMLPublication2();
		System.out.println("2.a");
		assertEquals(0,xb.averageMedianAndMeanPerAuthor("dblp_curated_sample.xml","publications"));
		System.out.println("2.b");
		assertEquals(0,xb.averageMedianAndMeanPerAuthor("dblp_curated_sample.xml","journalArticles"));
		System.out.println("2.c");
		assertEquals(0,xb.averageMedianAndMeanPerAuthor("dblp_curated_sample.xml","conferenceProceedings"));
		System.out.println("2.d");
		assertEquals(0,xb.averageMedianAndMeanPerAuthor("dblp_curated_sample.xml","books"));
		System.out.println("2.e");
		assertEquals(0,xb.averageMedianAndMeanPerAuthor("dblp_curated_sample.xml","bookChapters"));
	}
	
	//S�gol�ne
	@Test
	public void userStory3(){
		System.out.println("\nUSER STORY 3\n");
		XMLPublication2 xb = new XMLPublication2();
		System.out.println("3.a");
		assertEquals(0,xb.averageMedianAndMeanPerYear("dblp_curated_sample.xml","publications"));
		System.out.println("3.b");
		assertEquals(0,xb.averageMedianAndMeanPerYear("dblp_curated_sample.xml","conferenceProceedings"));
		System.out.println("3.c");
		assertEquals(0,xb.averageMedianAndMeanPerYear("dblp_curated_sample.xml","journalArticles"));
		System.out.println("3.d");
		assertEquals(0,xb.averageMedianAndMeanPerYear("dblp_curated_sample.xml","books"));
		System.out.println("3.e");
		assertEquals(0,xb.averageMedianAndMeanPerYear("dblp_curated_sample.xml","bookChapters"));
	}
	*/
	//Rachelle
	@Test
	public void userStory4(){
		System.out.println("\nUSER STORY 4\n");
		XMLPublication2 xb = new XMLPublication2();
		System.out.println("4.a");
		assertEquals(0,xb.averageMedianAndMeanOfAuthorPerYear("dblp_curated_sample.xml","publications"));
		System.out.println("4.b");
		assertEquals(0,xb.averageMedianAndMeanOfAuthorPerYear("dblp_curated_sample.xml","journalArticles"));
		System.out.println("4.c");
		assertEquals(0,xb.averageMedianAndMeanOfAuthorPerYear("dblp_curated_sample.xml","conferenceProceedings"));
		System.out.println("4.d");
		assertEquals(0,xb.averageMedianAndMeanOfAuthorPerYear("dblp_curated_sample.xml","books"));
		System.out.println("4.e");
		assertEquals(0,xb.averageMedianAndMeanOfAuthorPerYear("dblp_curated_sample.xml","bookChapters"));
	}
	
}
