package fr.dauphine.publications_analytics.src;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class XMLPublication3 {
	public HashMap getCoAuthors(String file_name, String authorName, String typeDocument, String startYear, String endYear){
		String year="";
		HashMap<String, Integer> coAuthorsList = new HashMap<String, Integer>();
		
		//Dates management
		if((!startYear.equals("") && endYear.equals(""))) //If only the starting date has been filled in (all the documents at this date)
			year = " and $x/year >= \"" +startYear+"\" ";
		else if	((startYear.equals("") && !endYear.equals(""))) //If only the ending date has been filled in (all the documents before this date)
			year = " and $x/year <= \"" +endYear+"\" ";
		else if ((!startYear.equals("") && !endYear.equals("")))//If the starting and ending date have not been filled in
			year = " and $x/year >= "+startYear+" and $x/year<= "+endYear;

		// Publication type management
		String document = "/*";
		if(typeDocument.equals("Publication"))
			document = "/*";
		if (typeDocument.equals("Article"))
			document = "/article";
		if (typeDocument.equals("Conference"))
			document = "/inproceedings";
		if (typeDocument.equals("Book"))
			document = "/book";
		if (typeDocument.equals("Chapter"))
			document = "/incollection";

		String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp"+document+" " +
				"where $x/author = \""+authorName+"\" "+year+" return $x/author//text()";

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);			
			while(seq.next()){
				//st.add(seq.getItem().getNode().getNodeValue());
				String coAuthor = seq.getItem().getNode().getNodeValue();
				if(!coAuthor.equals(authorName)){
					//System.out.println(coAuthor);
					if (coAuthorsList.containsKey(coAuthor))
						coAuthorsList.put(coAuthor, coAuthorsList.get(coAuthor)+1);
					else
						coAuthorsList.put(coAuthor, 1);
				}
			}
			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		//extractToCSV(coAuthorsList);
		System.out.println(coAuthorsList);
		return coAuthorsList;
	}

	public void extractToCSV(HashMap<String,Integer> coAuthorsList){
		try
		{
			FileWriter writer = new FileWriter("C:\\Users\\Raquel\\Extract.csv");

			for (String mapKey : coAuthorsList.keySet()) {
				writer.append(mapKey);
				writer.append(',');
				writer.append(coAuthorsList.get(mapKey).toString());
				writer.append('\n');
			}

			writer.flush();
			writer.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		} 

	}

	public Set<String> getAuthor(String file_name) {

		Set st=new TreeSet();
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*/author " +
				"return $x//text() ";
		//System.out.println("XQuery query:"+query);
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);			
			while(seq.next()){
				st.add(seq.getItem().getNode().getNodeValue());
				//System.out.println(st.toString());
			}
			Iterator i = st.iterator();
			//while(i.hasNext()){
			//System.out.println(i.next());
			//}
			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		//System.out.println("fini");
		return st;
	}
}
