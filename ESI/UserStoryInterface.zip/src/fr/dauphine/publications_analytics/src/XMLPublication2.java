package fr.dauphine.publications_analytics.src;

import java.util.*;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class XMLPublication2 {
	public Set<String> get_yearC(String file_name) {

		
		Set st=new TreeSet();
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*/year " +
				"return $x//text() ";
		
		//System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);			
			while(seq.next()){
				st.add(seq.getItem().getNode().getNodeValue());
			//	System.out.println(st.toString());
			}
			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return st;
	}
	
public Set<String> get_Publication(String file_name,String typeDocument) {
	String specific = "";
	if(typeDocument.equals("publications"))
		specific = "*";
	if (typeDocument.equals("journalArticles"))
			specific = "article";
	if (typeDocument.equals("conferenceProceedings"))
		specific = "inproceedings";
	if (typeDocument.equals("books"))
		specific = "book";
	if (typeDocument.equals("bookChapters"))
		specific = "incollection";
		Set st=new TreeSet();
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp/"+specific+" " +
				"return $x/@key ";
		//System.out.println("XQuery query:"+query);
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);			
			while(seq.next()){
				st.add(seq.getItem().getNode().getNodeValue());
				//System.out.println(st.toString());
			}
			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return st;
	}
	public Set<String> get_authorC(String file_name) {
		
		Set st=new TreeSet();
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*/author " +
				"return $x//text() ";
		//System.out.println("XQuery query:"+query);
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);			
			while(seq.next()){
				st.add(seq.getItem().getNode().getNodeValue());
				//System.out.println(st.toString());
			}
			Iterator i = st.iterator();
			//while(i.hasNext()){
				//System.out.println(i.next());
			//}
			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		//System.out.println("fini");
		return st;
	}

	public Map<String, Integer> get_number_of_author_per_publication(String file_name, Set<String> set, String typeDocument) {
		Map<String,Integer> map=new HashMap(); 
		String specific = "";
		if(typeDocument.equals("publications"))
			specific = "*";
		if (typeDocument.equals("journalArticles"))
				specific = "article";
		if (typeDocument.equals("conferenceProceedings"))
			specific = "inproceedings";
		if (typeDocument.equals("books"))
			specific = "book";
		if (typeDocument.equals("bookChapters"))
			specific = "incollection";
		int nbPublication=0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		Iterator i = set.iterator();
		while(i.hasNext()){
			//System.out.println(i.next());
			String title=(String) i.next();
		//	String query = "for $x in doc(\"" +xml_file+ "\")/dblp/* " +
			//	"return count($x/author)";
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp "+
			"return count(for $y in $x/"+specific+"/author where $y/../@key = \""+ title +"\" return 1)";
			//System.out.println("XQuery query:"+query);
		
			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nbPublication=seq.getInt();
				//System.out.println("le nombre de auteur est "+ nbPublication + " pour " + title);
				seq.close();
		
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
			map.put(title, nbPublication);
		}
		
		System.out.println(map);
		return map;
	}
	
	//Rachelle
	public Map<String, Integer> get_number_of_publication_par_authorC(String file_name, Set<String> set, String typeDocument) {
		Map<String,Integer> map=new HashMap(); 
		String specific = "";
		if(typeDocument.equals("publications"))
			specific = "$x/*";
		if (typeDocument.equals("journalArticles"))
				specific = "$x/article";
		if (typeDocument.equals("conferenceProceedings"))
			specific = "$x/inproceedings";
		if (typeDocument.equals("books"))
			specific = "$x/book";
		if (typeDocument.equals("bookChapters"))
			specific = "$x/incollection";
		int nbPublication=0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		Iterator i = set.iterator();
		while(i.hasNext()){
			//System.out.println(i.next());
			String auteur=(String) i.next();
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in "+specific+" where $y/author = \""+ auteur +"\" return 1)";

			//System.out.println("XQuery query:"+query);
		
			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nbPublication=seq.getInt();
				//System.out.println("le nombre de publication est pour "+ auteur + " est " + nbPublication);
				seq.close();
		
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
			map.put(auteur, nbPublication);
		}
		
		System.out.println(map);
		return map;
	}
	
	//Segolene
	public Map<String, Integer> get_number_of_publication_par_yearC(String file_name, Set<String> set, String typeDocument) {
		Map<String,Integer> map=new HashMap(); 
		String specific = "";
		if(typeDocument.equals("publications"))
			specific = "$x/*";
		if (typeDocument.equals("journalArticles"))
				specific = "$x/article";
		if (typeDocument.equals("conferenceProceedings"))
			specific = "$x/inproceedings";
		if (typeDocument.equals("books"))
			specific = "$x/book";
		if (typeDocument.equals("bookChapters"))
			specific = "$x/incollection";
		int nbConf=0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		Iterator i = set.iterator();
		while(i.hasNext()){
			//System.out.println(i.next());
			String year=(String) i.next();
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in "+specific+" where $y/year = \""+ year +"\" return 1)";

			//System.out.println("XQuery query:"+query);
		
			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nbConf=seq.getInt();
				//System.out.println("le nombre de publication pr " + year +" est "+ nbConf);
				seq.close();
		
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
			map.put(year, nbConf);
		}
		
		System.out.println(map);
		return map;
	}
	//USER STORY 2
 //A)Rachelle
	public double averageNumberOfPublicationsForAnAuthor(String file_name, Map<String,Integer> map){
		//Map<String,Integer> map = get_number_of_publication_par_authorC(file_name,get_authorC(file_name)); 
		int nbPublication = 0;
		double average = 0;
		String xml_file = getClass().getResource(file_name).toExternalForm();
		Map<String, String> hashMap = new HashMap<String, String>();
		for (String mapKey : map.keySet()) {
			average += map.get(mapKey);
		}
		//System.out.println("average = "+average/map.size());
		int test = 5/2;
	//	System.out.println("2/5 = "+test);
		return average/map.size();
	}
	
	// S�go
	public double medianNumberOfPublicationsForAnAuthor(String file_name, Map<String,Integer> map){
		//Map<String,Integer> map = get_number_of_publication_par_authorC(file_name,get_authorC(file_name)); 
		int nbPublication = 0;
		double average = 0;
		String xml_file = getClass().getResource(file_name).toExternalForm();
		Map<String, String> hashMap = new HashMap<String, String>();
		int i =0;
		
		int premi�re_valeur_indice = map.size()/2;
		
		List l= new ArrayList(map.values());
		Collections.sort(l);
		//System.out.println("liste : "+l);
		if (map.size() % 2 == 0){
			int borne_inf =(Integer)l.get((l.size()-1)/2);
			int borne_sup =(Integer)l.get((l.size())/2);
			//System.out.println("median = "+(borne_inf+borne_sup)/2);
			return (borne_inf+borne_sup)/2;
		}
		//System.out.println("median = "+(Integer)l.get(l.size()/2));
		return (Integer)l.get(l.size()/2);
	
	}
	
	// S�gol�ne
	public Set modeNumberOfPublicationsForAnAuthor(String file_name, Map<String,Integer> map){
		//Map<String,Integer> map = get_number_of_publication_par_authorC(file_name,get_authorC(file_name));
		Map <Integer, Integer> mapFrequence = new HashMap<Integer, Integer>();
		int max = 0;
		for (String mapKey : map.keySet()) {
			int keyFrequence = map.get(mapKey);
			if (mapFrequence.containsKey(keyFrequence)){
				mapFrequence.put(keyFrequence, mapFrequence.get(keyFrequence)+1);
			}else{
				mapFrequence.put(keyFrequence, 1);
			}
			if(mapFrequence.get(keyFrequence) > max){
				max = mapFrequence.get(keyFrequence);
			}
		}
		Set modeSet = new TreeSet();
		for(Integer mapKey : mapFrequence.keySet()){
			if (mapFrequence.get(mapKey) == max){
				modeSet.add(mapKey);
			}
		}
		
		return modeSet;
	}
	
	//Segol�ne
	public  Map<String, Integer> get_number_of_publication_in_each_year(String file_name, Set<String> setYear, String typeDocument  ) {
		Map<String,Integer> map = new HashMap(); 
		String specific = "*";
		if(typeDocument.equals("publications"))
			specific = "*";
		if (typeDocument.equals("journalArticles"))
				specific = "article";
		if (typeDocument.equals("conferenceProceedings"))
			specific = "inproceedings";
		if (typeDocument.equals("books"))
			specific = "book";
		if (typeDocument.equals("bookChapters"))
			specific = "incollection";
		
		
	
				try{
					//int nbYear=0;
					String xml_file = getClass().getResource(file_name).toExternalForm();
					Iterator j = setYear.iterator();
						while(j.hasNext()){
							int nbAuth=0;
							String year=(String) j.next();
							//nbYear++;
							//String query = "for $x in doc(\"" +xml_file+ "\")/dblp/"+specific+"[./year=\""+ year +"\"] " +
								//"return count(for $y in $x/author return 1)";

							String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
							"return count(for $y in $x/"+specific+"[./year=\""+ year +"\"]/author return 1)";
					//System.out.println("query: "+query);
					XQDataSource ds = new SaxonXQDataSource();
					XQConnection conn = ds.getConnection();
					XQExpression exp = conn.createExpression();
			
					XQSequence seq = exp.executeQuery(query);	
					seq.next();
					//System.out.println(seq.getInt());
					nbAuth=seq.getInt();
					//System.out.println("le nombre de d'auteur  pr " + year + " est " + nbAuth );
					map.put(year, nbAuth);
					seq.close();
					}
				} catch (XQException err) {
					System.out.println("Failed as expected: " + err.getMessage());
				}
			
			//System.out.println(map);
		return map;
	}
	
	public int averageMedianAndMean(String filename, String typeDocument){
		 Map<String, Integer>numberOfPublicationParAuthorC = get_number_of_author_per_publication(filename, get_Publication(filename, typeDocument), typeDocument);
		
		double average = averageNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		double median = medianNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		Set mode = modeNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		System.out.println("Average = "+average);
		System.out.println("Median = "+median);
		System.out.println("Mode = "+mode);
		return 0;
	}
	//Rachelle
	public int averageMedianAndMeanPerAuthor(String filename, String typeDocument){
		 Map<String, Integer>numberOfPublicationParAuthorC = get_number_of_publication_par_authorC(filename, get_authorC(filename), typeDocument);
		
		double average = averageNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		double median = medianNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		Set mode = modeNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
		System.out.println("Average = "+average);
		System.out.println("Median = "+median);
		System.out.println("Mode = "+mode);
		return 0;
	}
	//Rachelle
	public int averageMedianAndMeanPerYear(String filename, String typeDocument){
		 Map<String, Integer>numberOfPublicationParAuthorC = get_number_of_publication_par_yearC(filename, get_yearC(filename), typeDocument);
			
			double average = averageNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			double median = medianNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			Set mode = modeNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			System.out.println("Average = "+average);
			System.out.println("Median = "+median);
			System.out.println("Mode = "+mode);
			return 0;
	}
	
	public int averageMedianAndMeanOfAuthorPerYear(String filename, String typeDocument){
		 Map<String, Integer>numberOfPublicationParAuthorC = get_number_of_publication_in_each_year(filename, get_yearC(filename), typeDocument);
			System.out.println(numberOfPublicationParAuthorC);
			double average = averageNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			double median = medianNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			Set mode = modeNumberOfPublicationsForAnAuthor(filename, numberOfPublicationParAuthorC);
			System.out.println("Average = "+average);
			System.out.println("Median = "+median);
			System.out.println("Mode = "+mode);
			return 0;
	}
}
