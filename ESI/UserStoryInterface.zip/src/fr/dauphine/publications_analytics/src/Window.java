package fr.dauphine.publications_analytics.src;
/*
  Group name: E-SI
  Students: Habiba ALAMI, Gueoula COHEN, S�gol�ne PICARD, Rachelle SENA DE FREITAS
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Set;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class Window extends JFrame{
	//Elements de l'IHM
	private JPanel form = new JPanel(new GridLayout(5,2)); //5 rows, 2 columns
	private JPanel buttons = new JPanel(new GridLayout(1,2)); //1 row, 2 columns
	private JPanel bottom = new JPanel(new GridLayout(0,1)); //1 column
	private JLabel labAuthor = new JLabel("Author");
	XMLPublication3 doc = new XMLPublication3(); 
	private JLabel labStartYear = new JLabel("From");
	private JTextField jtStartYear = new JTextField();
	private JLabel labEndYear = new JLabel("To");
	private JTextField jtEndYear = new JTextField();
	private String[] choices = {"Book", "Chapter", "Conference", "Collection", "Publication"};
	private JLabel labDocumentType = new JLabel("Select a document type");
	private JComboBox jcDocumentType = new JComboBox(choices);
	private JTable jtResults;
	private JButton jbSearch = new JButton ("Search");
	private JButton jbExtract = new JButton ("Extract");
	String[][] dataToUpdate;
	private JLabel labXML = new JLabel("XML file");
	private String[] choicesXML = {"dblp_1.xml", "dblp_2.xml", "dblp_curated_sample.xml"};
	private JComboBox jcXmlFile = new JComboBox(choicesXML);
	private JComboBox<String> jtAuthor = new JComboBox<String>(doc.getAuthor(jcXmlFile.getSelectedItem().toString()).toArray(new String [0]));

	public Window(){
		this.setTitle("Doctor research"); //Title of the window
		this.setSize(1000, 300); //Size of the window
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //To close when the user presses "exit"
		this.setLocationRelativeTo(null);
		this.setLayout(new GridLayout(2,1));//2 rows,1 column
		Font police = new Font("Arial", Font.BOLD, 14); //Font style
		jtAuthor.setFont(police); //Set the font using the style described above
		jtStartYear.setFont(police); //Set the font using the style described above
		jtEndYear.setFont(police); //Set the font using the style described above
		dataToUpdate = new String[100][100];
		String  title[] = {"Co author", "Frequency"};
		this.jtResults = new JTable(dataToUpdate, title);

		//Actions to be performed when the user clicks the buttons
		
		//Research button behaviour
		jbSearch.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg){
				XMLPublication3 myDoc = new XMLPublication3();
				HashMap<String, Integer>result = new HashMap<String, Integer>();
				result = myDoc.getCoAuthors(jcXmlFile.getSelectedItem().toString(), jtAuthor.getSelectedItem().toString(), jcDocumentType.getSelectedItem().toString(), jtStartYear.getText(), jtEndYear.getText());

				Set<String> coAuthors = result.keySet();
				if (coAuthors.size() != 0){//If any results
					int index = 0;
					for (String mapKey : result.keySet()) {
						dataToUpdate[index][0] = mapKey;
						dataToUpdate[index][1] = result.get(mapKey).toString();
						index ++;
					}
				}else { //If no result
					for (int i=0; i<100; i++){
						dataToUpdate[i][0] = "";
						dataToUpdate[i][1] = "";
					}
				}
				jtResults.updateUI(); //Make the update available (if not, the table still looks the same)
			}
		}
				);
		
		//Extract button behaviour
		jbExtract.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg){
				XMLPublication3 myDoc = new XMLPublication3();
				HashMap<String, Integer>result = new HashMap<String, Integer>();
				result = myDoc.getCoAuthors(jcXmlFile.getSelectedItem().toString(), jtAuthor.getSelectedItem().toString(), jcDocumentType.getSelectedItem().toString(), jtStartYear.getText(), jtEndYear.getText());
				myDoc.extractToCSV(result);
			}
		}
				);
		
		//CoAuthor selection behaviour
		jtResults.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent evt){
				jtAuthor.setSelectedItem(dataToUpdate[evt.getFirstIndex()][0]);
			}
		});
		
		//XML dropdown list behaviour
		jcXmlFile.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				jtAuthor.removeAllItems();
				for(String str : doc.getAuthor(jcXmlFile.getSelectedItem().toString()).toArray(new String [0])){
					jtAuthor.addItem(str);
				}
				jtAuthor.updateUI();
			}
		});
		
		//Window management
		form.add(labAuthor);
		form.add(labAuthor);
		form.add(jtAuthor);
		form.add(new JLabel(" "));
		form.add(new JLabel(" "));
		form.add(labStartYear);
		form.add(jtStartYear);
		form.add(labEndYear);
		form.add(jtEndYear);
		form.add(labXML);
		form.add(jcXmlFile);
		form.add(new JLabel(" "));
		form.add(new JLabel(" "));
		form.add(labDocumentType);
		form.add(jcDocumentType);
		form.add(new JLabel(" "));
		form.add(new JLabel(" "));
		form.add(jbSearch);
		form.add(jbExtract);
		bottom.add(new JScrollPane(jtResults));
		this.add(form);
		this.add(bottom);
		this.setVisible(true);     
	} 



	public static void main(String[] args) {
		JFrame myWindow = new Window();
	}
}