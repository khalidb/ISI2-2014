package fr.dauphine.publications_analytics.src;
import java.util.*;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;


public class XMLPublication {
	
	
	public int get_number_of_publicationsA(String file_name) {
		
		return 0;
		
	}
	
	public int get_number_of_publicationsB(String file_name) {
		
		return 1;
		
	}
	
	public int get_number_of_publicationsC(String file_name) {
		
		int number_of_publications = 0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in $x/* return 1)";
		
		System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
	
			XQSequence seq = exp.executeQuery(query);			
	
			seq.next();
			
			number_of_publications = seq.getInt();
	
			System.out.println("Number of publications of is "+number_of_publications);
			
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_publications;
	}
	

	public int get_number_of_author_appearancesA(String file_name) {
		
		return 0;
		
	}
	
	
	
	public int get_number_of_author_appearancesB(String file_name) {
		
		return 2;
		
	}
	
	public int get_number_of_author_appearancesC(String file_name) {
		
		int number_of_author_appearances = 0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in $x/*/author return 1)";
		
		System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
	
			XQSequence seq = exp.executeQuery(query);			
	
			seq.next();
			
			number_of_author_appearances = seq.getInt();
	
			System.out.println("Number of authors of is "+number_of_author_appearances);
			
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_author_appearances;
		
	}
	
	
	public double get_mean_number_of_authors_per_publicationA(String file_name) {
		
		double mean = 0.0;
		
		return mean;
		
	}
	
	public double get_mean_number_of_authors_per_publicationB(String file_name) {
		
		double mean = 2.0;
		
		return mean;
		
	}
	
	
	public double get_mean_number_of_authors_per_publicationC(String file_name) {
		
		double mean = 0.0;
		
		double num_publications = this.get_number_of_publicationsC(file_name);
		double num_authors = this.get_number_of_author_appearancesC(file_name);
		
		mean = num_authors/num_publications;
		
		return mean;
		
	}
//---------1------------
public int get_number_of_publicationC(String file_name) {
		
		int number_of_book = 0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in $x/* return 1)";//$x c <dblp>
		
		System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
	
			XQSequence seq = exp.executeQuery(query);			
	
			seq.next();
			
			number_of_book = seq.getInt();
	
			System.out.println("Number of article is "+number_of_book);
			
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_book;
	}
public int get_number_of_auteurC(String file_name) {
	
	int number_of_book = 0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	
	String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/author return 1)";//$x c <dblp>
	
	System.out.println("XQuery query:"+query);

	try{
		XQDataSource ds = new SaxonXQDataSource();
		XQConnection conn = ds.getConnection();
		XQExpression exp = conn.createExpression();


		XQSequence seq = exp.executeQuery(query);			

		seq.next();
		
		number_of_book = seq.getInt();

		System.out.println("Number of article is "+number_of_book);
		
		seq.close();

	} catch (XQException err) {
		System.out.println("Failed as expected: " + err.getMessage());
	}
	
	return number_of_book;
}
public int get_number_of_conferenceC(String file_name) {
	
	int number_of_book = 0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	
	String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/inproceedings return 1)";//$x c <dblp>
	
	System.out.println("XQuery query:"+query);

	try{
		XQDataSource ds = new SaxonXQDataSource();
		XQConnection conn = ds.getConnection();
		XQExpression exp = conn.createExpression();


		XQSequence seq = exp.executeQuery(query);			

		seq.next();
		
		number_of_book = seq.getInt();

		System.out.println("Number of article is "+number_of_book);
		
		seq.close();

	} catch (XQException err) {
		System.out.println("Failed as expected: " + err.getMessage());
	}
	
	return number_of_book;
}
public int get_number_of_articleC(String file_name) {
		
		int number_of_book = 0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in $x/article return 1)";//$x c <dblp>
		
		System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
	
			XQSequence seq = exp.executeQuery(query);			
	
			seq.next();
			
			number_of_book = seq.getInt();
	
			System.out.println("Number of article is "+number_of_book);
			
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_book;
	}
	
public int get_number_of_bookC(String file_name) {
		
		int number_of_book = 0;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
				"return count(for $y in $x/book return 1)";//$x c <dblp>
		
		System.out.println("XQuery query:"+query);

		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
	
			XQSequence seq = exp.executeQuery(query);			
	
			seq.next();
			
			number_of_book = seq.getInt();
	
			System.out.println("Number of book is "+number_of_book);
			
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_book;
	}
public int get_number_of_book_chapterC(String file_name) {
	
	int number_of_book = 0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	
	String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/incollection return 1)";//$x c <dblp>
	
	System.out.println("XQuery query:"+query);

	try{
		XQDataSource ds = new SaxonXQDataSource();
		XQConnection conn = ds.getConnection();
		XQExpression exp = conn.createExpression();


		XQSequence seq = exp.executeQuery(query);			

		seq.next();
		
		number_of_book = seq.getInt();

		System.out.println("Number of book chapters is "+number_of_book);
		
		seq.close();

	} catch (XQException err) {
		System.out.println("Failed as expected: " + err.getMessage());
	}
	
	return number_of_book;
}

//-----2-------------
public Set<String> get_authorC(String file_name) {
	
	Set st=new TreeSet();
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	
	String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*/author " +
			"return $x//text() ";
	
	//System.out.println("XQuery query:"+query);

	try{
		XQDataSource ds = new SaxonXQDataSource();
		XQConnection conn = ds.getConnection();
		XQExpression exp = conn.createExpression();


		XQSequence seq = exp.executeQuery(query);			
		while(seq.next()){
			st.add(seq.getItem().getNode().getNodeValue());
			//System.out.println(st.toString());
		}
		Iterator i = st.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
		seq.close();

	} catch (XQException err) {
		System.out.println("Failed as expected: " + err.getMessage());
	}
	System.out.println("fini");
	return st;
}

public Map<String, Integer> get_number_of_publication_par_authorC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbPublication=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String auteur=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/* where $y/author = \""+ auteur +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbPublication=seq.getInt();
			System.out.println("le nombre de publication est pour "+ auteur + " est " + nbPublication);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(auteur, nbPublication);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_conference_par_authorC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String auteur=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/inproceedings where $y/author = \""+ auteur +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de inproccedings est "+ nbConf +" pour " + auteur  );
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(auteur, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_article_par_authorC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String auteur=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/article where $y/author = \""+ auteur +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de inproccedings pr " + auteur +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(auteur, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_book_par_authorC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String auteur=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/book where $y/author = \""+ auteur +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de inproccedings pr " + auteur +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(auteur, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_chapitre_par_authorC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String auteur=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/incollection where $y/author = \""+ auteur +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de inproccedings pr " + auteur +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(auteur, nbConf);
	}
	
	System.out.println(map);
	return map;
}
//-------------------------3----------------------

public Set<String> get_yearC(String file_name) {
	
	Set st=new TreeSet();
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	
	String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*/year " +
			"return $x//text() ";
	
	System.out.println("XQuery query:"+query);

	try{
		XQDataSource ds = new SaxonXQDataSource();
		XQConnection conn = ds.getConnection();
		XQExpression exp = conn.createExpression();


		XQSequence seq = exp.executeQuery(query);			
		while(seq.next()){
			st.add(seq.getItem().getNode().getNodeValue());
			System.out.println(st.toString());
		}
		Iterator i = st.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
		seq.close();

	} catch (XQException err) {
		System.out.println("Failed as expected: " + err.getMessage());
	}
	
	return st;
}
public Map<String, Integer> get_number_of_publication_par_yearC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String year=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
		"return count(for $y in $x/* where $y/year = \""+ year +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de publication pr " + year +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(year, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_conference_par_yearC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String year=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
		"return count(for $y in $x/inproceedings where $y/year = \""+ year +"\" return 1)";


		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de conference pr " + year +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(year, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_article_par_yearC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String year=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/article where $y/year = \""+ year +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre d'article pr " + year +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(year, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_book_par_yearC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String year=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/book where $y/year = \""+ year +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de livre pr " + year +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(year, nbConf);
	}
	
	System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_chapitre_par_yearC(String file_name, Set<String> set) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator i = set.iterator();
	while(i.hasNext()){
		//System.out.println(i.next());
		String year=(String) i.next();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
			"return count(for $y in $x/incollection where $y/year = \""+ year +"\" return 1)";

		//System.out.println("XQuery query:"+query);
	
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
	
			XQSequence seq = exp.executeQuery(query);			
			seq.next();
			nbConf=seq.getInt();
			System.out.println("le nombre de chapitre pr " + year +" est "+ nbConf);
			seq.close();
	
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		map.put(year, nbConf);
	}
	
	System.out.println(map);
	return map;
}

//-------------4----------------------

public  Map<String, Integer> get_number_of_publication_in_each_yearC(String file_name, Set<String> setYear ) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	int nbYear=0;
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator j = setYear.iterator();
		while(j.hasNext()){
			String year=(String) j.next();
			nbYear++;
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp/*[./year =  \""+ year +"\"] " +
				"return count(for $y in $x/author   return 1)";

			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nbConf=seq.getInt();
				//System.out.println("le nombre de d'auteur  pr " + year + " est " + nbConf );
				map.put(year, nbConf);
				seq.close();
				
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
		}
		System.out.println(map);
	return map;
}
public Map<String, Integer> get_number_of_conference_in_each_yearC(String file_name, Set<String> setYear ) {
	Map<String,Integer> map=new HashMap(); 
	int nbConf=0;
	int nbYear=0;
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator j = setYear.iterator();
		while(j.hasNext()){
			String year=(String) j.next();
			nbYear++;
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp/inproceedings[./year =  \""+ year +"\"] " +
				"return count(for $y in $x/author   return 1)";

			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nbConf=seq.getInt();
				//System.out.println("le nombre de d'auteur  pr " + year + " est " + nbConf );
				map.put(year, nbConf);
				seq.close();
				
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
		}
		System.out.println(map);
	return map;
	
}

public Map<String,Integer> get_number_of_article_in_each_yearC(String file_name, Set<String> setYear ) {
	Map<String,Integer> map=new HashMap(); 
	int nb=0;

	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator j = setYear.iterator();
		while(j.hasNext()){
			String year=(String) j.next();
			//String query = "for $x in doc(\"" +xml_file+ "\")/dblp/article[./year =  \""+ year +"\"] " +
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp/article[./year =  \""+ year +"\"] " +
				"return count(for $y in $x/author   return 1)";

			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nb=seq.getInt();

				map.put(year, nb);
				seq.close();
				
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
		}
		System.out.println(map);
	return map;
	
	
	
	
}
public Map<String,Integer> get_number_of_book_in_each_yearC(String file_name, Set<String> setYear ) {
	Map<String,Integer> map=new HashMap(); 
	int nb=0;
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator j = setYear.iterator();
		while(j.hasNext()){
			String year=(String) j.next();
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp/book[./year =  \""+ year +"\"] " +
				"return count(for $y in $x/author   return 1)";

			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nb=seq.getInt();

				map.put(year, nb);
				seq.close();
				
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
		}
		System.out.println(map);
	return map;

}
public Map<String,Integer> get_number_of_chapitre_in_each_yearC(String file_name, Set<String> setYear ) {
	Map<String,Integer> map=new HashMap(); 
	int nb=0;
	String xml_file = getClass().getResource(file_name).toExternalForm();
	Iterator j = setYear.iterator();
		while(j.hasNext()){
			String year=(String) j.next();
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp/incollection[./year =  \""+ year +"\"] " +
				"return count(for $y in $x/author   return 1)";

			try{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
		
				XQSequence seq = exp.executeQuery(query);			
				seq.next();
				nb=seq.getInt();
				map.put(year, nb);
				seq.close();
				
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}
		}
		System.out.println(map);
	return map;
	
	
	
	
}
}
