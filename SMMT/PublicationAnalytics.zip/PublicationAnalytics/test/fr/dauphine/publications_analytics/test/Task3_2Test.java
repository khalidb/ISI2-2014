package fr.dauphine.publications_analytics.test;



import java.util.ArrayList;

import fr.dauphine.publications_analytics.src.Task3_2;

public class Task3_2Test 
{
	double mean;
	int median;
	ArrayList<Integer> modal;
	String file_name;
	
	public Task3_2Test(String file_name)
	{this.file_name = file_name;}
	
	
	public void questionA()
	{
		Task3_2 v = new Task3_2("author",file_name,"*");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionB()
	{
		Task3_2 v = new Task3_2("author",file_name,"article");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionC()
	{
		Task3_2 v = new Task3_2("author",file_name,"inproceedings");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionD()
	{
		Task3_2 v = new Task3_2("author",file_name,"book");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionE()
	{
		Task3_2 v = new Task3_2("author",file_name,"incollection");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}


	public static void main(String[] args)
	{

	
		Task3_2Test task2 = new Task3_2Test("dblp_curated_sample.xml");
		task2.questionA();
		System.out.println("Question a :");
		System.out.println("Moyenne : "+task2.getMean());
		System.out.println("Mediane : "+task2.getMedian());
		System.out.println("Mode :"+task2.getModal());
		task2.questionB();
		System.out.println("Question b :");
		System.out.println("Moyenne : "+task2.getMean());
		System.out.println("Mediane : "+task2.getMedian());
		System.out.println("Mode :"+task2.getModal());
		task2.questionC();
		System.out.println("Question c :");
		System.out.println("Moyenne : "+task2.getMean());
		System.out.println("Mediane : "+task2.getMedian());
		System.out.println("Mode :"+task2.getModal());
		task2.questionD();
		System.out.println("Question d :");
		System.out.println("Moyenne : "+task2.getMean());
		System.out.println("Mediane : "+task2.getMedian());
		System.out.println("Mode :"+task2.getModal());
		task2.questionE();
		System.out.println("Question e :");
		System.out.println("Moyenne : "+task2.getMean());
		System.out.println("Mediane : "+task2.getMedian());
		System.out.println("Mode :"+task2.getModal());
		
	}
	

	public double getMean()
	{return this.mean;}
	
	public int getMedian()
	{return this.median;}
	
	public ArrayList<Integer> getModal()
	{return this.modal;}
}


