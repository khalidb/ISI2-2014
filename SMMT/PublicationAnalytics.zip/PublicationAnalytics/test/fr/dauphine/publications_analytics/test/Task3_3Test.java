package fr.dauphine.publications_analytics.test;



import java.util.ArrayList;

import fr.dauphine.publications_analytics.src.Task3_3;

public class Task3_3Test 
{
	double mean;
	double median;
	ArrayList<Integer> modal;
	String file_name;
	
	public Task3_3Test(String file_name)
	{this.file_name = file_name;}
	

	public void questionA()
	{
		Task3_3 v = new Task3_3("year",file_name,"*");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionB()
	{
		Task3_3 v = new Task3_3("year",file_name,"inproceedings");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionC()
	{
		Task3_3 v = new Task3_3("year",file_name,"article");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionD()
	{
		Task3_3 v = new Task3_3("year",file_name,"book");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionE()
	{
		Task3_3 v = new Task3_3("year",file_name,"incollection");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}


	public static void main(String[] args)
	{
		
	
		Task3_3Test task3 = new Task3_3Test("dblp_curated_sample.xml");
		task3.questionA();
		System.out.println("Question a :");
		System.out.println("Moyenne : "+task3.getMean());
		System.out.println("Mediane :"+task3.getMedian());
		System.out.println("Mode : "+task3.getModal());
		task3.questionB();
		System.out.println("Question b :");
		System.out.println("Moyenne : "+task3.getMean());
		System.out.println("Mediane :"+task3.getMedian());
		System.out.println("Mode : "+task3.getModal());
		task3.questionC();
		System.out.println("Question c :");
		System.out.println("Moyenne : "+task3.getMean());
		System.out.println("Mediane :"+task3.getMedian());
		System.out.println("Mode : "+task3.getModal());
		task3.questionD();
		System.out.println("Question d :");
		System.out.println("Moyenne : "+task3.getMean());
		System.out.println("Mediane :"+task3.getMedian());
		System.out.println("Mode : "+task3.getModal());
		task3.questionE();
		System.out.println("Question e :");
		System.out.println("Moyenne : "+task3.getMean());
		System.out.println("Mediane :"+task3.getMedian());
		System.out.println("Mode : "+task3.getModal());
	
	}
	
	
	public double getMean()
	{return (double)Math.round(this.mean * 100) / 100;}
	
	public double getMedian()
	{return this.median;}
	
	public ArrayList<Integer> getModal()
	{return this.modal;}
}
