package fr.dauphine.publications_analytics.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import fr.dauphine.publications_analytics.src.Task3;
import fr.dauphine.publications_analytics.src.Task4_1;
import fr.dauphine.publications_analytics.src.Task4_2;
import fr.dauphine.publications_analytics.src.Task4_3;
import fr.dauphine.publications_analytics.src.Task4_4;
import fr.dauphine.publications_analytics.src.XMLPublication;


public class XMLPublicationTest {


	//QUESTION 1

	/*

@Test

public void should_support_one_publication() throws Exception {

String file_name = "dblp_1.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_number_of_publicationsC(file_name));

}

@Test


public void sould_support_multiple_publications() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(3,

xb.get_number_of_publicationsC(file_name));

}


@Test

public void should_support_two_author_appearances() throws Exception {

String file_name = "dblp_1.xml";

XMLPublication xb = new XMLPublication();

assertEquals(2,

xb.get_number_of_author_appearancesC(file_name));

}


	 */



	/*

@Test

public void should_support_seven_author_appearances() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(7,

xb.get_number_of_author_appearancesC(file_name));

}


@Test

public void should_support_one_conference_proceeding() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_number_of_conference_proceedingA(file_name));

}


@Test

public void should_support_one_journal_article() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_number_of_journal_articlesA(file_name));

}


@Test

public void should_support_one_book() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_number_of_bookA(file_name));

}


@Test

public void should_support_one_chapter() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_number_of_chapterA(file_name));

}

	 */

	//QUESTION 2

	/*

@Test

public void testAuthorPublicationBonjeu() throws Exception {

String file_name = "dblp_curated_sample.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors_publication(file_name));


}


@Test


public void testAuthorPublicationJeudc() throws Exception {

String file_name = "dblp_3.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors(file_name,1));

}


	@Test


public void testAuthorConfproceedJeudc() throws Exception {

String file_name = "dblp_3.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors(file_name,2));

}


@Test

public void testAuthorjournalarticleJeudc() throws Exception {

String file_name = "dblp_3.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors(file_name,3));

}


@Test

public void testAuthorbookJeudc() throws Exception {

String file_name = "dblp_3.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors(file_name,4));

}


@Test

public void testAuthorChapterJeudc() throws Exception {

String file_name = "dblp_3.xml";

XMLPublication xb = new XMLPublication();

assertEquals(1,

xb.get_authors(file_name,5));

}


	 */

	//QUESTION 3 
/*
	@Test

	public void testYearPublicationJeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,
				xb.get_year(file_name,1));

	}



	@Test


	public void testYearConfproceedJeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,
				xb.get_year(file_name,2));

	}



	@Test

	public void testYearjournalarticleJeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year(file_name,3));

	}



	@Test


	public void testYearbookJeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,
				xb.get_year(file_name,4));

	}



	@Test


	public void testYearChapterJeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year(file_name,5));

	}

*/
	//QUESTION 4
	/*
	@Test

	public void Test4_1_Jeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year2(file_name,1));

	}
	
	@Test

	public void Test4_2_Jeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year2(file_name,2));

	}
	
	@Test

	public void Test4_3_Jeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year2(file_name,3));

	}
	
	@Test

	public void Test4_4_Jeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year2(file_name,4));

	}
	
	@Test

	public void Test4_5_Jeudc() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,

				xb.get_year2(file_name,5));

	}

*/

	/////////////////////////////////////////////////////////////



	/*


@Test


public void should_have_two_as_a_mean() throws Exception {


String file_name = "dblp_1.xml";


double delta = 0.0;


XMLPublication xb = new XMLPublication();


assertEquals(2.0,


xb.get_mean_number_of_authors_per_publicationC(file_name),delta);





}





@Test


public void should_have_two_thirtythree_as_mean() throws Exception {


String file_name = "dblp_2.xml";


double delta = 0.004;


XMLPublication xb = new XMLPublication();


assertEquals(2.33,


xb.get_mean_number_of_authors_per_publicationB(file_name),delta);


}

	 */
	
	
	/*@Test

	public void Test_average_1a() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,xb.get_average_authors_per_publication(file_name));

	}*/

	/*
	@Test

	public void Test_median_1a() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();
	
		assertEquals(1,xb.get_median_author_per_publication(file_name));

	}
*//*
	@Test

	public void Test_mode_1a() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();
	
		
		Task3 t=new Task3(element, file_name, type);
	//	assertEquals(1,xb.get_mode_author_per_publication(new HashMap<String, ArrayList<String>>()));

	}
/*	
	@Test

	public void Test_average_1b() throws Exception {

		String file_name = "dblp_curated_sample.xml";

		XMLPublication xb = new XMLPublication();

		assertEquals(1,xb.get_average_authors_per_article(file_name));

	}
*/
	

	
	/*@Test
	public void Test_4_1() throws Exception {

		String file_name = "dblp_3.xml";

		Task4_1 xb = new Task4_1(file_name);
	
		//assertEquals(1,xb.get_median_author_per_publication(file_name));

	}*/
	/*
	@Test
	public void Test_4_2() throws Exception {

		String file_name = "dblp_3.xml";

		Task4_2 xb = new Task4_2(file_name,1997,1999);
	
		//assertEquals(1,xb.get_median_author_per_publication(file_name));

	}
	*/
	/*
	@Test
	public void Test_4_3() throws Exception {

		String file_name = "dblp_3.xml";

		Task4_3 xb = new Task4_3(file_name,"book");
	
		//assertEquals(1,xb.get_median_author_per_publication(file_name));

	}
	*/
	/*
	@Test
	public void Test_4_4() throws Exception {

		String file_name = "dblp_3.xml";

		Task4_4 xb = new Task4_4(file_name,"Patrice Seyed");
	
		//assertEquals(1,xb.get_median_author_per_publication(file_name));

	}
	*/
}
