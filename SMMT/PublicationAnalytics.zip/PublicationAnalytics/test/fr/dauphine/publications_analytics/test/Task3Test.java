package fr.dauphine.publications_analytics.test;



import java.util.ArrayList;

import fr.dauphine.publications_analytics.src.Task3;

public class Task3Test 
{
	double mean;
	int median;
	ArrayList<Integer> modal;
	String file_name;
	
	public Task3Test(String file_name)
	{
		this.file_name = file_name;
	}
	

	public void questionA()
	{
		Task3 v = new Task3("author",file_name,"*");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionB()
	{
		Task3 v = new Task3("author",file_name,"article");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionC()
	{
		Task3 v = new Task3("author",file_name,"inproceedings");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionD()
	{
		Task3 v = new Task3("author",file_name,"incollection");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}
	public void questionE()
	{
		Task3 v = new Task3("author",file_name,"book");
		this.mean = v.getMean();
		this.median = v.getMedian();
		this.modal = v.getModal();
	}


	public static void main(String[] args)
	{
		

		Task3Test task = new Task3Test("dblp_curated_sample.xml");
		task.questionA();
		System.out.println("Question a :");
		System.out.println("Moyenne : "+task.getMean());
		System.out.println("Mediane : "+task.getMedian());
		System.out.println("Mode : "+task.getModal());
		task.questionB();
		System.out.println("Question b :");
		System.out.println("Moyenne : "+task.getMean());
		System.out.println("Mediane : "+task.getMedian());
		System.out.println("Mode : "+task.getModal());
		task.questionC();
		System.out.println("Question c :");
		System.out.println("Moyenne : "+task.getMean());
		System.out.println("Mediane : "+task.getMedian());
		System.out.println("Mode : "+task.getModal());
		task.questionD();
		System.out.println("Question d :");
		System.out.println("Moyenne : "+task.getMean());
		System.out.println("Mediane : "+task.getMedian());
		System.out.println("Mode : "+task.getModal());
		task.questionE();
		System.out.println("Question e :");
		System.out.println("Moyenne : "+task.getMean());
		System.out.println("Mediane : "+task.getMedian());
		System.out.println("Mode : "+task.getModal());
		
	}
	
	
	public double getMean()
	{return this.mean;}
	
	public int getMedian()
	{return this.median;}
	
	public ArrayList<Integer> getModal()
	{return this.modal;}
}
