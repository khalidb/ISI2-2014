package fr.dauphine.publications_analytics.src;

import java.io.File;
import java.net.MalformedURLException;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class Task4_4 {

	public Task4_4(File file_name, String author) {

		namesCoauthors(file_name, author);
	}

	public String namesCoauthors(File file_name, String author) {

		String str = author+" : ";
		//String xml_file = getClass().getResource(file_name).toExternalForm();
		
		String query="";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values(for $y in $x/* where $y/author= \""
					+ author + "\" return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);
			
			String coAuthor;
			while (seq.next() == true) {

				coAuthor = seq.getItemAsString(null);

				if (!coAuthor.equals(author)) {
						str = str + "," + coAuthor;
				}
			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());
		}
		System.out.println(str);
		return str;
	}
}
