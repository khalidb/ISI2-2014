package fr.dauphine.publications_analytics.src;

import java.io.File;
import java.net.MalformedURLException;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class Task4_2 {

	String str; 
	public Task4_2(File file_name, int minYear, int maxYear) {
		
		
		for(int i=minYear;i<=maxYear;i++)
		{
			get_authors(file_name, i);
		}
		
		
	}

	public String get_authors(File file_name, int year) {

		String str = "";

		//String xml_file = getClass().getResource(file_name).toExternalForm();

		String query="";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp " +

			"return distinct-values(for $y in $x/* where $y/year = \"" + year
					+ "\" return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();

			XQSequence seq = exp.executeQuery(query);
			
			
			String temp;
			String author = "";
			if (seq.next() == false) {
				
				System.out.println(year + "\nNo publications");
		
			} else {
				System.out.println(year);
		  
			}
			while (seq.next() == true) {

				author = seq.getItemAsString(null);
				temp = author + " : " + namesCoauthors(file_name, author, year);

				System.out.println(temp);
				str = str + temp;

			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}

		
		return   str;

	}

	public String namesCoauthors(File file_name, String author, int year) {

		String str = "";

		String sortedBy = "*";
		//String xml_file = getClass().getResource(file_name).toExternalForm();

		String query="";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values(for $y in $x/" + sortedBy
					+ " where $y/author= \"" + author + "\" and $y/year=\"" + year
					+ "\"  return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();

			XQSequence seq = exp.executeQuery(query);

			String s;

			while (seq.next() == true) {

				s = seq.getItemAsString(null);

				if (!s.equals(author)) {
					if (str.equals("")) {
						str = s;
					} else {
						str = str + "," + s;
					}
				}
			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}

		return str;
	}

}
