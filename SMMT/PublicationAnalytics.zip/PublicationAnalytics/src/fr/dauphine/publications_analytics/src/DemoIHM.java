package fr.dauphine.publications_analytics.src;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.Button;

import java.io.File; 
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.*; 
import javax.swing.*;
import javax.swing.filechooser.*;



public class DemoIHM extends JFrame {

	 JPanel contentPane;
	List list1 = new List();

	JTextField textField;
	JTextField textField_1;
	JButton btnOk;
	JLabel lblYears;
	int datee;
	int datee1;
	File f;
	String filename = "dblp_3.xml";
	String typePublication;
	JRadioButton rdbtnBookChapters;
	JRadioButton rdbtnBook;
	JRadioButton rdbtnConferencePub;
	JButton button;
	JRadioButton rdbtnArticles;
	PrintStream fichier;
	
	


	public static void main(String[] args) throws FileNotFoundException {
		DemoIHM frame = new DemoIHM();
		frame.setVisible(true);
	}


	public DemoIHM() throws FileNotFoundException {
		final PrintStream fichier=new PrintStream(new FileOutputStream("export.csv"));
		fichier.println("Authors");
		fichier.println("");
		
		JOptionPane.showMessageDialog(this,"Please begin with Task5 to select your XML folder.");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		JLabel lblTest = new JLabel("- SMMT - Author Collaborations Demonstration");
		panel.add(lblTest);
		
		final JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.WEST);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{86, 86};
		gbl_panel_1.rowHeights = new int[]{29, 0, 0, 0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{0.0};
		gbl_panel_1.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JButton btnNewButton = new JButton("Task 1");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Task4_1 t1 = new Task4_1 ("dblp_3.xml");
			
			
				list1.removeAll();
				String pst = "See names of the co-authors for each author in the publications set";
				String res = new Task4_1(f).get_authors(f);
				list1.add(res);
			}
		});
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 0;
		panel_1.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Task 2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				list1.removeAll();
				String pst = "See names of the co-authors for each author set in particular date: Choose years";
				list1.add(pst);
				
				
			}
		});
		
		final JRadioButton rdbtnBook = new JRadioButton("Book");
		rdbtnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list1.removeAll();
				Task4_3 t = new Task4_3(f, "book"); 
				String res =t.get_authors(f, "book");
				list1.add(res);
				
	
			}
			});
		
		GridBagConstraints gbc_rdbtnBook = new GridBagConstraints();
		gbc_rdbtnBook.insets = new Insets(0, 0, 5, 0);
		gbc_rdbtnBook.gridx = 1;
		gbc_rdbtnBook.gridy = 0;
		panel_1.add(rdbtnBook, gbc_rdbtnBook);
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton_1.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnNewButton_1.gridx = 0;
		gbc_btnNewButton_1.gridy = 1;
		panel_1.add(btnNewButton_1, gbc_btnNewButton_1);
		rdbtnBook.setVisible(false);
		
		
		final JRadioButton rdbtnBookChapters = new JRadioButton("Book Chapters");
		rdbtnBookChapters.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list1.removeAll();
				Task4_3 t = new Task4_3(f, "incollection"); 
				String res =t.get_authors(f, "incollection");
				list1.add(res);
	
			}
			});
		
		final JRadioButton rdbtnConferencePub = new JRadioButton("Conference Pub.");
		rdbtnConferencePub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list1.removeAll();
				Task4_3 t = new Task4_3(f, "inproceedings"); 
				String res =t.get_authors(f, "inproceedings");
				list1.add(res);
	
			}
			});
		
		GridBagConstraints gbc_rdbtnConferencePub = new GridBagConstraints();
		gbc_rdbtnConferencePub.insets = new Insets(0, 0, 5, 0);
		gbc_rdbtnConferencePub.gridx = 1;
		gbc_rdbtnConferencePub.gridy = 2;
		panel_1.add(rdbtnConferencePub, gbc_rdbtnConferencePub);
		rdbtnConferencePub.setVisible(false);
		
		final JRadioButton rdbtnArticles = new JRadioButton("Articles");
		rdbtnArticles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list1.removeAll();
				Task4_3 t = new Task4_3(f, "article"); 
				String res =t.get_authors(f, "article");
				list1.add(res);
	
			}
			});
		GridBagConstraints gbc_rdbtnArticles = new GridBagConstraints();
		gbc_rdbtnArticles.insets = new Insets(0, 0, 5, 0);
		gbc_rdbtnArticles.gridx = 1;
		gbc_rdbtnArticles.gridy = 3;
		panel_1.add(rdbtnArticles, gbc_rdbtnArticles);
		rdbtnArticles.setVisible(false);
		
		
		JButton btnTask = new JButton("Task 3");
		btnTask.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//panel_1.remove(btnOk);
				list1.removeAll();
				
				rdbtnBook.setVisible(true);
				rdbtnBookChapters.setVisible(true); 
				rdbtnConferencePub.setVisible(true);
				rdbtnArticles.setVisible(true);
				
			}
		});
		
		
		GridBagConstraints gbc_rdbtnBookChapters = new GridBagConstraints();
		gbc_rdbtnBookChapters.insets = new Insets(0, 0, 5, 0);
		gbc_rdbtnBookChapters.gridx = 1;
		gbc_rdbtnBookChapters.gridy = 1;
		panel_1.add(rdbtnBookChapters, gbc_rdbtnBookChapters);
		GridBagConstraints gbc_btnTask = new GridBagConstraints();
		gbc_btnTask.insets = new Insets(0, 0, 5, 5);
		gbc_btnTask.gridx = 0;
		gbc_btnTask.gridy = 2;
		panel_1.add(btnTask, gbc_btnTask);
		rdbtnBookChapters.setVisible(false);
		
		
		final Button button = new Button("See him co-authors");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = list1.getSelectedItem();
				Task4_4 t2 = new Task4_4(f, nom);
				
				String info = t2.namesCoauthors(f, nom);
				
				String in = "+++++++++++ Co authors +++++++++";
				list1.add(in);
				list1.add(info);
				
				
			}
		});
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 0);
		gbc_button.gridx = 1;
		gbc_button.gridy = 4;
		panel_1.add(button, gbc_button);
		button.setVisible(false);
		
		JButton btnTask_1 = new JButton("Task 4");
		btnTask_1.addActionListener(new ActionListener() {
		

			public void actionPerformed(ActionEvent e) {
			rdbtnBook.setVisible(false);
				rdbtnBookChapters.setVisible(false); 
				rdbtnConferencePub.setVisible(false);
				rdbtnArticles.setVisible(false);
				button.setVisible(true);
				list1.removeAll();
				
				Task4_1 t = new Task4_1(f); 
				
				java.util.List res = t.get_name_authors(filename);
				
				for(int i=0;i<=res.size();i++)
				{
					list1.add((String) res.get(i));
					fichier.println((String) res.get(i));
					
					
				}
				fichier.flush();
				fichier.close();
			//	int index=list1.getSelectedIndex();
				
				
			}}
			);
	
		GridBagConstraints gbc_btnTask_1 = new GridBagConstraints();
		gbc_btnTask_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnTask_1.gridx = 0;
		gbc_btnTask_1.gridy = 3;
		panel_1.add(btnTask_1, gbc_btnTask_1);
		
		
		/********** A COMPLETER **********/
		
		JButton btnTask_2 = new JButton("Task 5");
		btnTask_2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				FileFilter xml = new FiltreSimple("Fichiers XML",".xml");
				JFileChooser chooser = new JFileChooser(new File("."));
				chooser.addChoosableFileFilter(xml);
				//chooser.showOpenDialog(null);
				File fichier;
				PrintWriter sortie;
			
				
				if (chooser.showOpenDialog(null)== 
				    JFileChooser.APPROVE_OPTION) {
				    fichier = chooser.getSelectedFile();
				    f = fichier;
				    try {
						sortie = new PrintWriter
						(new FileWriter(fichier.getPath(), true));
						
					    sortie.close();
					} catch (IOException ef) {
						// TODO Auto-generated catch block
						ef.printStackTrace();
						
					}
								
				list1.removeAll();
				
				
				
			}
				
			}});
		
		GridBagConstraints gbc_btnTask_2 = new GridBagConstraints();
		gbc_btnTask_2.insets = new Insets(0, 0, 5, 5);
		gbc_btnTask_2.gridx = 0;
		gbc_btnTask_2.gridy = 4;
		panel_1.add(btnTask_2, gbc_btnTask_2);
		
		
		
		JButton btnTask_3 = new JButton("Task 6");
	btnTask_3.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				String pst ="Vos donn�es ont bien �t� enregistr�s ";
				
				list1.removeAll();
				list1.add(pst);
				
		
				
				
				
			}});
	
	
	
	
		GridBagConstraints gbc_btnTask_3 = new GridBagConstraints();
		gbc_btnTask_3.insets = new Insets(0, 0, 0, 5);
		gbc_btnTask_3.gridx = 0;
		gbc_btnTask_3.gridy = 5;
		panel_1.add(btnTask_3, gbc_btnTask_3);
		contentPane.add(list1, BorderLayout.CENTER);
				
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.EAST);
		panel_2.setLayout(new GridLayout());
		
		JPanel panel_3 = new JPanel();
		contentPane.add(panel_3, BorderLayout.SOUTH);
		
		JLabel lblYears = new JLabel("Years");
		panel_3.add(lblYears);
		lblYears.setVisible(false);
		
		textField = new JTextField();
		panel_3.add(textField);
		textField.setColumns(10);
		textField.setVisible(true);
		
		textField_1 = new JTextField();
		panel_3.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setVisible(true);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String date = textField.getText();
				String date1 = textField_1.getText();
				datee = Integer.parseInt(date); 
				datee1 = Integer.parseInt(date1); 
				Task4_2 t = new Task4_2(f, datee, datee1);
				for(int i=datee;i<=datee1;i++)
				{
					String res = t.get_authors(f, i);
					
					list1.add(res + "\n" );
				}
				
			}
		});
		panel_3.add(btnOk);
		
		
		
	}

}
