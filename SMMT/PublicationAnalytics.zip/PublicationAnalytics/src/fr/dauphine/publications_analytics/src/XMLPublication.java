package fr.dauphine.publications_analytics.src;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;

import java.util.Iterator;

import java.util.List;

import java.util.Map;

import java.util.Set;

import java.util.TreeSet;
import java.util.Map.Entry;


import javax.xml.xquery.XQConnection;

import javax.xml.xquery.XQDataSource;

import javax.xml.xquery.XQException;

import javax.xml.xquery.XQExpression;

import javax.xml.xquery.XQSequence;


import net.sf.saxon.xqj.SaxonXQDataSource;




public class XMLPublication {


	// QUESTION 1



	public int get_number_of_publicationsA(String file_name) {



		return 0;



	}



	public int get_number_of_publicationsB(String file_name) {



		return 1;



	}



	public int get_number_of_publicationsC(String file_name) {



		int number_of_publications = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/* return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_publications = seq.getInt();



			System.out.println("Number of publications of is "+number_of_publications);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_publications;

	}




	public int get_number_of_author_appearancesA(String file_name) {



		return 0;



	}







	public int get_number_of_author_appearancesB(String file_name) {



		return 2;



	}



	public int get_number_of_author_appearancesC(String file_name) {



		int number_of_author_appearances = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count (for $y in distinct-values( $x/*/author) return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_author_appearances = seq.getInt();



			System.out.println("Number of authors of is "+number_of_author_appearances);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_author_appearances;



	}





	public double get_mean_number_of_authors_per_publicationA(String file_name) {



		double mean = 0.0;



		return mean;



	}



	public double get_mean_number_of_authors_per_publicationB(String file_name) {



		double mean = 2.0;



		return mean;



	}





	public double get_mean_number_of_authors_per_publicationC(String file_name) {



		double mean = 0.0;



		double num_publications = this.get_number_of_publicationsC(file_name);

		double num_authors = this.get_number_of_author_appearancesC(file_name);



		mean = num_authors/num_publications;



		return mean;



	}

	

	public int get_number_of_conference_proceedingA(String file_name) {



		int number_of_conference_proceeding = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/inproceedings return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_conference_proceeding = seq.getInt();



			System.out.println("Number of conference is "+number_of_conference_proceeding);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_conference_proceeding;



	}



	public int get_number_of_journal_articlesA(String file_name) {



		int number_of_journal_articles = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/article return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_journal_articles = seq.getInt();



			System.out.println("Number of article is "+number_of_journal_articles);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_journal_articles;



	}



	public int get_number_of_bookA(String file_name) {



		int number_of_books = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/book return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_books = seq.getInt();



			System.out.println("Number of books is "+number_of_books);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_books;



	}



	public int get_number_of_chapterA(String file_name) {



		int number_of_chapters = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/incollection return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_chapters = seq.getInt();



			System.out.println("Number of chapters is "+number_of_chapters);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_chapters;



	}









	// QUESTION 2



	public int get_number_of_conferences_by_author(String file_name,

			String author_name) {

		int number_of_publications = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" + xml_file + "\")/dblp "

		+ "return count (for $y in $x/inproceedings where $y/author = \"" + author_name

		+ "\" return 1)";



		System.out.println("XQuery query:" + query);


		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			seq.next();


			number_of_publications = seq.getInt();




			System.out.println("Number of conference by "+ author_name + " is "+ number_of_publications );


			seq.close();


		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_publications;

	}





	public int get_number_of_book_by_author(String file_name,String author_name) {

		int number_of_book = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" + xml_file + "\")/dblp "

		+ "return count (for $y in $x/book where $y/author = \"" + author_name

		+ "\" return 1)";



		System.out.println("XQuery query:" + query);


		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			seq.next();


			number_of_book = seq.getInt();




			System.out.println("Number of book by "+ author_name + " is "+ number_of_book );


			seq.close();


		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_book;

	}





	public int get_number_of_chapter_by_author(String file_name, String author_name) {

		int number_of_incollection = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" + xml_file + "\")/dblp "

		+ "return count (for $y in $x/incollection where $y/author = \"" + author_name

		+ "\" return 1)";



		System.out.println("XQuery query:" + query);


		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			seq.next();


			number_of_incollection = seq.getInt();




			System.out.println("Number of incollection by "+ author_name + " is "+ number_of_incollection );


			seq.close();


		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_incollection;

	}



	public int get_number_of_articles_by_author(String file_name, String author_name) {

		int number_of_articles = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" + xml_file + "\")/dblp "

		+ "return count (for $y in $x/article where $y/author = \"" + author_name

		+ "\" return 1)";



		System.out.println("XQuery query:" + query);


		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			seq.next();


			number_of_articles = seq.getInt();




			System.out.println("Number of article by "+ author_name + " is "+ number_of_articles );


			seq.close();


		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_articles;

	}





	public int get_number_of_publication_by_author(String file_name, String author) {


		int number_of_publication = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/* where $y/author = \"" + author + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_publication = seq.getInt();




			System.out.println("Number of publication by "+ author + " is "+ number_of_publication );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_publication;


	}










	public String get_authors(String file_name,int choix) {


		String authors = "";


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return distinct-values($x/*/author/text())";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			//Boolean b = seq.next();


			String s;


			while(seq.next()==true){


				//seq.next();


				s = seq.getItemAsString(null);

				if(choix==1)

				{

					get_number_of_publication_by_author(file_name, s);

				}

				else if(choix==2)

				{

					get_number_of_conferences_by_author(file_name,s);

				}

				else if(choix==3)

				{

					get_number_of_articles_by_author(file_name,s);

				}

				else if(choix==4)

				{

					get_number_of_book_by_author(file_name,s);

				}

				else if(choix==5)

				{

					get_number_of_chapter_by_author(file_name, s); }

			}


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return authors;

	}





	// QUESTION 3



	public int get_number_of_publication_by_year(String file_name, String year) {


		int number_of_publication = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/* where $y/year = \"" + year + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_publication = seq.getInt();




			System.out.println("Number of publication by "+ year + " is "+ number_of_publication );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_publication;


	}



	public int get_number_of_chapter_by_year(String file_name, String year) {


		int number_of_chapter = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/incollection where $y/year = \"" + year + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_chapter = seq.getInt();




			System.out.println("Number of chapter by "+ year + " is "+ number_of_chapter );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_chapter;


	}






	public int get_number_of_book_by_year(String file_name, String year) {


		int number_of_book = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/book where $y/year = \"" + year + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_book = seq.getInt();




			System.out.println("Number of book by "+ year + " is "+ number_of_book );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_book;


	}





	public int get_number_of_article_by_year(String file_name, String year) {


		int number_of_article = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/article where $y/year = \"" + year + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_article = seq.getInt();




			System.out.println("Number of article by "+ year + " is "+ number_of_article );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_article;


	}



	public int get_number_of_conference_by_year(String file_name, String year) {


		int number_of_conference = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return count(for $y in $x/inproceedings where $y/year = \"" + year + "\" return 1)";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query); 


			seq.next();


			number_of_conference = seq.getInt();




			System.out.println("Number of conference by "+ year + " is "+ number_of_conference );


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_conference;


	}








	public String get_year(String file_name,int choix) {


		String year = "";


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return distinct-values($x/*/year/text())";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			//Boolean b = seq.next();


			String s;


			while(seq.next()==true){


				//seq.next();


				s = seq.getItemAsString(null);

				if(choix==1)

				{

					get_number_of_publication_by_year(file_name, s);

				}

				else if(choix==2)

				{

					get_number_of_conference_by_year(file_name,s);

				}

				else if(choix==3)

				{

					get_number_of_article_by_year(file_name,s);

				}

				else if(choix==4)

				{

					get_number_of_book_by_year(file_name,s);

				}

				else if(choix==5)

				{

					get_number_of_chapter_by_year(file_name, s); }

			}


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return year;

	}


	public String get_year2(String file_name,int choix) {


		String year = "";


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +


		"return distinct-values($x/*/year/text())";


		System.out.println("XQuery query:"+query);


		try{


			XQDataSource ds = new SaxonXQDataSource();


			XQConnection conn = ds.getConnection();


			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			//Boolean b = seq.next();


			String s;


			while(seq.next()==true){


				//seq.next();


				s = seq.getItemAsString(null);

				if(choix==1)

				{

					get_number_of_authors_by_year(file_name, s);

				}

				else if(choix==2)

				{

					get_number_of_authors_by_year_conf(file_name,s);

				}

				else if(choix==3)

				{

					get_number_of_authors_by_year_article(file_name,s);

				}

				else if(choix==4)

				{

					get_number_of_authors_by_year_book(file_name,s);

				}

				else if(choix==5)

				{

					get_number_of_authors_by_year_incollection(file_name, s); }

			}


			seq.close();




		} catch (XQException err) {


			System.out.println("Failed as expected: " + err.getMessage());

		}


		return year;

	}

	public int get_number_of_authors_by_year(String file_name, String year) {

		int number_of_publication = 0;

	String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/*/author where $y/../year = \"" + year + "\" return 1)";

		System.out.println("XQuery query:"+query);

		try{

		XQDataSource ds = new SaxonXQDataSource();

	XQConnection conn = ds.getConnection();

	XQExpression exp = conn.createExpression();

	XQSequence seq = exp.executeQuery(query); 


	seq.next();

	number_of_publication = seq.getInt();
	
	System.out.println("Number of author by "+ year + " is "+ number_of_publication );

	seq.close();

		} catch (XQException err) {

		System.out.println("Failed as expected: " + err.getMessage());

	}
		return number_of_publication;

	}
	
	public int get_number_of_authors_by_year_conf(String file_name, String year) {

		int number_of_publication = 0;

	String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/inproceedings/author where $y/../year = \"" + year + "\" return 1)";

		System.out.println("XQuery query:"+query);

		try{

		XQDataSource ds = new SaxonXQDataSource();

	XQConnection conn = ds.getConnection();

	XQExpression exp = conn.createExpression();

	XQSequence seq = exp.executeQuery(query); 


	seq.next();

	number_of_publication = seq.getInt();
	
	System.out.println("Number of author conf by "+ year + " is "+ number_of_publication );

	seq.close();

		} catch (XQException err) {

		System.out.println("Failed as expected: " + err.getMessage());

	}
		return number_of_publication;

	}
	
	public int get_number_of_authors_by_year_article(String file_name, String year) {

		int number_of_publication = 0;

	String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/article/author where $y/../year = \"" + year + "\" return 1)";

		System.out.println("XQuery query:"+query);

		try{

		XQDataSource ds = new SaxonXQDataSource();

	XQConnection conn = ds.getConnection();

	XQExpression exp = conn.createExpression();

	XQSequence seq = exp.executeQuery(query); 


	seq.next();

	number_of_publication = seq.getInt();
	
	System.out.println("Number of author article by "+ year + " is "+ number_of_publication );

	seq.close();

		} catch (XQException err) {

		System.out.println("Failed as expected: " + err.getMessage());

	}
		return number_of_publication;

	}
	
	public int get_number_of_authors_by_year_book(String file_name, String year) {

		int number_of_publication = 0;

	String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/book/author where $y/../year = \"" + year + "\" return 1)";

		System.out.println("XQuery query:"+query);

		try{

		XQDataSource ds = new SaxonXQDataSource();

	XQConnection conn = ds.getConnection();

	XQExpression exp = conn.createExpression();

	XQSequence seq = exp.executeQuery(query); 


	seq.next();

	number_of_publication = seq.getInt();
	
	System.out.println("Number of author book by "+ year + " is "+ number_of_publication );

	seq.close();

		} catch (XQException err) {

		System.out.println("Failed as expected: " + err.getMessage());

	}
		return number_of_publication;

	}
	
	public int get_number_of_authors_by_year_incollection(String file_name, String year) {

		int number_of_publication = 0;

	String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count(for $y in $x/incollection/author where $y/../year = \"" + year + "\" return 1)";

		System.out.println("XQuery query:"+query);

		try{

		XQDataSource ds = new SaxonXQDataSource();

	XQConnection conn = ds.getConnection();

	XQExpression exp = conn.createExpression();

	XQSequence seq = exp.executeQuery(query); 


	seq.next();

	number_of_publication = seq.getInt();
	
	System.out.println("Number of author incollection by "+ year + " is "+ number_of_publication );

	seq.close();

		} catch (XQException err) {

		System.out.println("Failed as expected: " + err.getMessage());

	}
		return number_of_publication;

	}
	
	
	// TASK 3
	

	public int get_number_of_author_by_publication(String file_name,String title) {

		int number_of_author = 0;


		String xml_file = getClass().getResource(file_name).toExternalForm();


		String query = "for $x in doc(\"" + xml_file + "\")/dblp "

		+ "return count (for $y in $x/*/author where $y/../title = \"" + title

		+ "\" return 1)";



		System.out.println("XQuery query:" + query);


		try {

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();


			XQSequence seq = exp.executeQuery(query);


			seq.next();


			number_of_author = seq.getInt();




			//System.out.println("Number of author by "+ title + " is "+ number_of_author );


			seq.close();


		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}


		return number_of_author;

	}
	
	
	
	public int get_number_of_author(String file_name) {



		int number_of_author_appearances = 0;



		String xml_file = getClass().getResource(file_name).toExternalForm();



		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +

		"return count (for $y in ( $x/*/author) return 1)";



		System.out.println("XQuery query:"+query);


		try{

			XQDataSource ds = new SaxonXQDataSource();

			XQConnection conn = ds.getConnection();

			XQExpression exp = conn.createExpression();





			XQSequence seq = exp.executeQuery(query); 



			seq.next();



			number_of_author_appearances = seq.getInt();



			System.out.println("Number of authors of is "+number_of_author_appearances);



			seq.close();



		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}



		return number_of_author_appearances;



	}

	
	
	// TASK 3
	
	
	public float get_average_authors_per_publication(String file_name) {
	
		float numberAuthor=get_number_of_author(file_name);
		float numberPublication=get_number_of_publicationsC(file_name);
		
		
		float average=numberAuthor/numberPublication;
		System.out.println("Average: " + average);
		return average;
	}



	public int get_median_author_per_publication(String file_name) {
			int nbPublication=get_number_of_publicationsC(file_name);
			int tabInt[] = new int[nbPublication] ;
		
	
			String xml_file = getClass().getResource(file_name).toExternalForm();
	
	
			String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
	
	
			"return distinct-values($x/*/title/text())";
	
	
			System.out.println("XQuery query:"+query);
	
	
			try{
	
	
				XQDataSource ds = new SaxonXQDataSource();
	
	
				XQConnection conn = ds.getConnection();
	
	
				XQExpression exp = conn.createExpression();
	
	
				XQSequence seq = exp.executeQuery(query);
	
	
				//Boolean b = seq.next();
	
	
				String publication;
	
	int i=0;
				while(seq.next()==true){
	
	
					//seq.next();
	
	
					publication = seq.getItemAsString(null);
	
						tabInt[i]=get_number_of_author_by_publication(file_name, publication);
	
					i++;
	
				}
				
				
				seq.close();
	
			
	
			} catch(XQException err) {
	
	
				System.out.println("Failed as expected: " + err.getMessage());
	
			}
	
			Arrays.sort(tabInt);
			
			if(nbPublication % 2 ==0)
			{
				System.out.println((tabInt[(nbPublication/2)-2] + tabInt[(nbPublication/2)-1])/2);
				return (tabInt[(nbPublication/2)-2] + tabInt[(nbPublication/2)-1])/2;
				
			}
			else
			{
				System.out.println(tabInt[(nbPublication/2)]);
				return tabInt[(nbPublication/2)];
			}
			
	
		}

/*

	public int get_mode_author_per_publication(String file_name) {
		int nbPublication=get_number_of_publicationsC(file_name);
		Map tab=new Hashtable();


		//int tabInt[] = new int[nbPublication] ;
		
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
		"return distinct-values($x//title/text())";*/
	/*	System.out.println("XQuery query:"+query);


		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);
			//Boolean b = seq.next();
			String publication;
			int i=0;
			while(seq.next()==true){
				//seq.next();
				publication = seq.getItemAsString(null);
				
				int nb=get_number_of_author_by_publication(file_name, publication);
				if(tab.get(nb)!=null)
				{
					int d=(Integer)tab.get(nb);
					
					d=d+nb;
					tab.put(nb, d);
				}
				else
				{
					tab.put(nb, nb);
					
				}
				
				//tabInt[i]=get_number_of_author_by_publication(file_name, publication);
				i++;
			}
			seq.close();
		} catch(XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		Iterator it = tab.entrySet().iterator();
		int plusGrand=0;
	    while (it.hasNext()) {
	        Map.Entry pairs = (Map.Entry)it.next();
	       
	        if((Integer)pairs.getValue()>plusGrand)
	        {
	        	plusGrand=(Integer)pairs.getValue();
	        }
	        System.out.println(pairs.getKey() + " = " + pairs.getValue());
	    }

		
	    return plusGrand;
	}*/
	/////////////////
	/* mode*/
	
	public ArrayList<Integer> get_mode_author_per_publication(HashMap<String,ArrayList<String>> map)
	{

		//		System.out.println("debut calcul modal");
		ArrayList<Integer> modal = new ArrayList<Integer>();
		HashMap<String,Integer> nbOcc = new HashMap<String,Integer>();
		HashMap<Integer,Integer> modMap = new HashMap<Integer,Integer>();
//
		for(Entry<String, ArrayList<String>> entry : map.entrySet()) 
			nbOcc.put(entry.getKey(), entry.getValue().size());

	
//
		int max = -1;
		for(Entry<String, Integer> entry : nbOcc.entrySet()) 
		{
			int i = entry.getValue();
			if(modMap.containsKey(i))
				modMap.put(i, modMap.get(i)+1);
			else
				modMap.put(i, 0);
			if(max<modMap.get(i)+1)
				max=modMap.get(i)+1;
			
		}

//
		for(Entry<Integer, Integer> entry : modMap.entrySet())
		{
			if(entry.getValue()==max-1)
				modal.add(entry.getKey());
		}

		return modal;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	///////////////////////
	
	public int get_number_of_author_article(String file_name) {
		int number_of_author_appearances = 0;
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "for $x in doc(\"" +xml_file+ "\")/dblp " +
		"return count (for $y in ( $x/*/author) where $y/article return 1)";
		System.out.println("XQuery query:"+query);
		
		try{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);
			seq.next();
			number_of_author_appearances = seq.getInt();
			System.out.println("Number of authors of is "+number_of_author_appearances);
			seq.close();
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}
		
		return number_of_author_appearances;
	}
	
	public float get_average_authors_per_article(String file_name) { 
		float numberAuthor=get_number_of_author(file_name);
		float numberArticle=get_number_of_journal_articlesA(file_name);
		float average=numberAuthor/numberArticle;
		System.out.println("Average: " + average);
		return average;
	}
}




