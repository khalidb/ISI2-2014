package fr.dauphine.publications_analytics.src;

import java.io.File;
import java.net.MalformedURLException;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class Task4_3 {

	public Task4_3(File file_name, String typePublication) {
		get_authors(file_name, typePublication);
	}

	public String get_authors(File file_name, String typePublication) {

		String str = "";
		//String xml_file = getClass().getResource(file_name).toExternalForm();
		String query="";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values(for $y in $x/" + typePublication
					+ " return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);

			String temp;
			String author;
			while (seq.next() == true) {

				author = seq.getItemAsString(null);
				temp = author + " : "
						+ namesCoauthors(file_name, author, typePublication);
				System.out.println(temp);
				str = str + "\n" + temp;
			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}

		return str;

	}

	public String namesCoauthors(File file_name, String author,
			String typePublication) {

		String str = "";

		//String xml_file = getClass().getResource(file_name).toExternalForm();

		String query="";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values(for $y in $x/" + typePublication
					+ " where $y/author= \"" + author
					+ "\"  return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);

			String s;

			while (seq.next() == true) {

				s = seq.getItemAsString(null);
				if (!s.equals(author)) {
					if (str.equals("")) {
						str = s;
					} else {
						str = str + "," + s;
					}
				}
			}
			seq.close();
		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());
		}
		return str;
	}

}
