package fr.dauphine.publications_analytics.src;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;



public class Task3_4 
{

	private double mean;
	private Integer median;
	private ArrayList<Integer> modal;
	
	public Task3_4(String element,String file_name, String type)
	{

		ArrayList<String> keys = returnKeys(file_name,type);
		HashMap<String,HashMap<String,ArrayList<String>>> map = returnElementPerPublication(element,file_name,type);


		for(Entry<String, HashMap<String,ArrayList<String>>> entry : map.entrySet()) {
			String key = entry.getKey();

		}
		mean = mean(map);
		median = median(map);
		modal = modal(map);

	}




	public ArrayList<String> returnKeys(String file_name, String type) 
	{

		ArrayList<String> a = new ArrayList<String>();
		String str;
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "(doc(\"" + xml_file + "\")/dblp/" + type + "/xs:string(@key))";
		try 
		{
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence result = exp.executeQuery(query);
			while (result.next())
			{
				str = result.getAtomicValue();
				a.add(str);
			}			
		} catch (XQException err) 
		{
			System.out.println("Failed as expected: " + err.getMessage());
		}
		return a;
	}


	public HashMap<String,HashMap<String,ArrayList<String>>> returnElementPerPublication(String element, String file_name, String type) {
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String str;

		Task3 v = new Task3(element, file_name, type);
		HashMap<String,ArrayList<String>> mapBook = v.returnElementPerPublication(element,file_name,type);
		HashMap<String,HashMap<String,ArrayList<String>>> map = new HashMap<String,HashMap<String,ArrayList<String>>>();
		ArrayList<String> h = new ArrayList<String>();
		HashMap<String,ArrayList<String>> h2 = new HashMap<String,ArrayList<String>>(); 


		for (String key : mapBook.keySet())
		{
			String query = "for $y in (for $x in (doc(\"" + xml_file + "\")/dblp/"
					+ type + "[@key='"+ key +"']/year) " 
					+ "return $x) return xs:string($y)";
			try 
			{
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
				XQSequence result = exp.executeQuery(query);
				while (result.next())
				{

					str = result.getAtomicValue();	
					if(map.containsKey(str))
					{
						h = new ArrayList<String>();
						h.addAll(mapBook.get(key));
						map.get(str).put(key,h);
					}
					else
					{
						h = new ArrayList<String>();
						h.addAll(mapBook.get(key));
						h2 = new HashMap<String,ArrayList<String>>();
						h2.put(key, h);
						map.put(str,h2);
					}

				}		
			} catch (XQException err) 
			{System.out.println("Failed as expected: " + err.getMessage());}

		}
		return map;
	}


	public double mean(HashMap<String,HashMap<String,ArrayList<String>>> map)
	{
		double d = 0.0,mapSize = 0.0;
		HashMap<String,String> tmp = new HashMap<String,String>();
		for(Entry <String,HashMap<String,ArrayList<String>>> entry : map.entrySet()) 
		{
			for(Entry <String,ArrayList<String>> entryTmp : entry.getValue().entrySet())
			{
				for(String s : entryTmp.getValue())
					tmp.put(s, "");
			}
			d+=tmp.size();
			tmp.clear();
			mapSize++;
		}
		return d/mapSize;
	}


	public Integer median(HashMap<String,HashMap<String,ArrayList<String>>> map)
	{
		ArrayList<Integer> nbOcc = new ArrayList<Integer>();

		for(Entry <String,HashMap<String,ArrayList<String>>> entry : map.entrySet()) 
		{
			for(Entry<String,ArrayList<String>> entry2 : entry.getValue().entrySet())
				nbOcc.add(entry2.getValue().size());
		}
		Collections.sort(nbOcc);
		try
		{
			return nbOcc.get(nbOcc.size()/2);
		}
		catch(IndexOutOfBoundsException e)
		{
			return 0;
		}
	}



	public ArrayList<Integer> modal(HashMap<String,HashMap<String,ArrayList<String>>> map)
	{


		ArrayList<Integer> modal = new ArrayList<Integer>();
		HashMap<String,Integer> nbOcc = new HashMap<String,Integer>();
		HashMap<Integer,Integer> modMap = new HashMap<Integer,Integer>();
		HashMap<String,String> tmp = new HashMap<String,String>();

		for(Entry <String,HashMap<String,ArrayList<String>>> entry : map.entrySet()) 
		{
			for(Entry<String,ArrayList<String>> entry2 : entry.getValue().entrySet())
			{
				for(String s : entry2.getValue())
					tmp.put(s,"");
			}
			nbOcc.put(entry.getKey(), tmp.size());
			tmp.clear();
		}


		int max = -1;
		for(Entry<String, Integer> entry : nbOcc.entrySet()) 
		{
			int i = entry.getValue();
			if(modMap.containsKey(i))
				modMap.put(i, modMap.get(i)+1);
			else
				modMap.put(i, 0);
			if(max<modMap.get(i)+1)
				max=modMap.get(i)+1;

		}



		for(Entry<Integer, Integer> entry : modMap.entrySet())
		{
			if(entry.getValue()==max-1)
				modal.add(entry.getKey());
		}

		return modal;
	}



	public double getMean()
	{return this.mean;}

	public int getMedian()
	{return this.median;}

	public ArrayList<Integer> getModal()
	{return this.modal;}
}
