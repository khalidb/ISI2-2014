package fr.dauphine.publications_analytics.src;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class Task3_3 {

	private double mean;
	private double median;
	private ArrayList<Integer> modal;

	public Task3_3(String element, String file_name, String type) {
		ArrayList<String> keys = returnKeys(file_name, element);

		HashMap<String, Integer> map = returnElementPerPublication(element,
				file_name, type);

	}

	public ArrayList<String> returnKeys(String file_name, String element) { // ici
																			// elt
																			// =
																			// year
		ArrayList<String> a = new ArrayList<String>();
		String str;
		String xml_file = getClass().getResource(file_name).toExternalForm();
		String query = "(doc(\"" + xml_file + "\")/dblp/*/xs:string(" + element
				+ "))";
		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence result = exp.executeQuery(query);

			while (result.next()) {
				str = result.getAtomicValue();
				if (!a.contains(str)) {
					a.add(str);
				}
			}
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return a;
	}

	public HashMap<String, Integer> returnElementPerPublication(String element,
			String file_name, String type) {
		String xml_file = getClass().getResource(file_name).toExternalForm();
		HashMap<String, Integer> map = new HashMap<String, Integer>();

		ArrayList<String> keys = returnKeys(file_name, element);

		for (String key : keys) {
			String query = "(doc(\"" + xml_file + "\")/dblp/" + type + "["
					+ element + "=" + key + "]/xs:string(@key) ) ";

			try {
				XQDataSource ds = new SaxonXQDataSource();
				XQConnection conn = ds.getConnection();
				XQExpression exp = conn.createExpression();
				XQSequence result = exp.executeQuery(query);
				while (result.next()) {
					if (!map.containsKey(key)) {
						map.put(key, 1);
					} else {
						map.put(key, map.get(key) + 1);
					}

					// System.out.println("KEY : " + key + " | VALUE : "+
					// map.get(key));
				}
			} catch (XQException err) {
				System.out.println("Failed as expected: " + err.getMessage());
			}

		}
		mean(map);
		median(map);
		modal(map);
		return map;
	}

	public Map<String, Integer> sortHasmap(Map<String, Integer> map) {
		Map<String, Integer> sortedMap = new TreeMap<String, Integer>(map);
		return sortedMap;
	}

	public String getiemeKey(Map<String, Integer> map, int Indice) {
		String out = null;
		int i = 0;
		for (String key : map.keySet()) {
			if (i == Indice) {
				out = key;
				break;
			}
			i++;
		}
		return out;
	}

	public void mean(HashMap<String, Integer> map) {
		Map<String, Integer> sortedMap = sortHasmap(map);
		int first = Integer.parseInt(getiemeKey(sortedMap, 0));
		int last;
		int taille = sortedMap.size();
		if (taille != 0) {
			last = Integer.parseInt(getiemeKey(sortedMap,
					(sortedMap.size() - 1)));
		} else {
			last = first;
		}
		int nbYear = last - first;
		int nbType = 0;

		for (String key : sortedMap.keySet()) {
			nbType += sortedMap.get(key);
		}
		this.mean = (double) nbType / nbYear;
	}

	public void median(HashMap<String, Integer> map) {
		Map<String, Integer> sortedMap = sortHasmap(map);
		double median = 0.0;

		if (map.size() != 0) {
			int taille = map.size() - 1;
			int n = taille / 2;

			if (taille % 2 != 0) {
				String key = getiemeKey(sortedMap, n);
				median = (double) sortedMap.get(key);
			} else {
				String key = getiemeKey(sortedMap, n - 1);
				String key2 = getiemeKey(sortedMap, n);
				median = (double) (sortedMap.get(key) + sortedMap.get(key2)) / 2;
			}
			this.median = median;
		}
	}

	public void modal(HashMap<String, Integer> map) {
		ArrayList<Integer> modal = new ArrayList<Integer>();

		HashMap<Integer, Integer> Occ = new HashMap<Integer, Integer>();
		for (String key : map.keySet()) {
			Integer v = map.get(key);
			if (Occ.containsKey(v)) {
				Occ.put(v, (Occ.get(v) + 1));
			} else {
				Occ.put(v, 1);
			}
		}

		Integer OccMax = 1;
		for (Integer key : Occ.keySet()) {
			if (Occ.get(key) > OccMax) {
				OccMax = Occ.get(key);
			}
		}

		for (Integer key : Occ.keySet()) {
			if (Occ.get(key) == OccMax) {
				modal.add(key);
			}
		}

		this.modal = new ArrayList<Integer>();
		int i;
		for (i = 0; i < modal.size(); i++) {
			this.modal.add(modal.get(i));
		}
	}

	public double getMean() {
		return this.mean;
	}

	public double getMedian() {
		return this.median;
	}

	public ArrayList<Integer> getModal() {
		return this.modal;
	}
}
