package fr.dauphine.publications_analytics.src;

import java.awt.List;
import java.io.File;
import java.net.MalformedURLException;
import java.util.Vector;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class Task4_1 {

	public Task4_1(File file_name) {

		get_authors(file_name);
		//get_name_authors(file_name);
	}

	public String get_authors(File file_name) {

		String str = "";

		/*String xml_file = getClass().getResource(file_name).toExternalForm();
*/

		String query = "";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values($x/*/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);

			String author;
			String temp;
			while (seq.next() == true) {

				author = seq.getItemAsString(null);
				temp = author + " : " + namesCoauthors(file_name, author);
				System.out.println(temp);
				str = str + "\n" + temp;
			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}

		return str;

	}

	public String namesCoauthors(File file_name, String author) {

		String str = "";

		//String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "";
		try {
			query = "for $x in doc(\"" + file_name.toURI().toURL().toExternalForm() + "\")/dblp "
					+ "return distinct-values(for $y in $x/* where $y/author= \""
					+ author + "\"  return $y/author/text())";
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);

			String s;

			while (seq.next() == true) {
				s = seq.getItemAsString(null);

				if (!s.equals(author)) {
					if (str.equals("")) {
						str = s;
					} else {
						str = str + "," + s;
					}
				}
			}

			seq.close();
		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}
		return str;
	}
	
	
	public Vector get_name_authors(String file_name) {

		List str = new List();
		Vector zeros=new Vector();

		String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" + xml_file + "\")/dblp "
				+ "return distinct-values($x/*/author/text())";

		try {

			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();
			XQSequence seq = exp.executeQuery(query);

			String author;
			String temp;
			while (seq.next() == true) {

				author = seq.getItemAsString(null);
				temp = author;
				System.out.println(temp);
				str.add(author);
				
		        zeros.add(author);
		      
		    
			}

			seq.close();

		} catch (XQException err) {

			System.out.println("Failed as expected: " + err.getMessage());

		}

		return zeros;

	}

}
