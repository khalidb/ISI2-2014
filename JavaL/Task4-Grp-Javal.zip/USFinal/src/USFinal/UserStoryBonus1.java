package USFinal;

import java.io.ObjectInputStream.GetField;
import java.util.*;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class UserStoryBonus1 {
	private List<String> list_authors;
	private List<String> list_coauthors;
	private HashMap<String, List<String>> map_author_coauthor;

	public UserStoryBonus1(String file_name) {
		execute(file_name);
	}

	public List<String> getList_authors() {
		return list_authors;
	}

	public HashMap<String, List<String>> getHashish() {
		return map_author_coauthor;
	}

	public void setList_authors(List<String> list_authors) {
		this.list_authors = list_authors;
	}

	public List<String> getList_coauthors() {
		return list_coauthors;
	}

	public void setList_coauthors(List<String> list_coauthors) {
		this.list_coauthors = list_coauthors;
	}

	public HashMap<String, List<String>> getMap_author_coauthor() {
		return map_author_coauthor;
	}

	public void setMap_author_coauthor(
			HashMap<String, List<String>> map_author_coauthor) {
		this.map_author_coauthor = map_author_coauthor;
	}

	public List get_list_authors(String file_name) {
		list_authors = new ArrayList();

		String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" + xml_file
				+ "\")/dblp/* return node-name($x)";

		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();

			XQSequence seq = exp.executeQuery(query);

			while (seq.next()) {
				String value = seq.getObject().toString();
				if (!list_authors.contains(value))
					list_authors.add(value);
			}

			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return list_authors;
	}

	public List get_list_coauthors_by_author(String file_name) {
		list_coauthors = new ArrayList();
		String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" + xml_file
				+ "\")/dblp return distinct-values($x/*)";

		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();

			XQSequence seq = exp.executeQuery(query);

			String tempo;

			while (seq.next()) {
				tempo = seq.getObject().toString();
				list_coauthors.add(tempo);
			}

			seq.close();

		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return list_coauthors;
	}

	public void execute(String file) {
		// UserStoryBonus1 us1 = new UserStoryBonus1(file_name);
		String file_name = file;

		get_list_authors(file_name);

	}

}