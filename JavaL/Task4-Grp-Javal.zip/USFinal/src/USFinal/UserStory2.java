package USFinal;

import java.io.ObjectInputStream.GetField;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class UserStory2 {
	private List<String> list_authors;
	private List<String> list_coauthors;
	private List list_years;
	private HashMap<String, List<String>> map_author_coauthor;

	public UserStory2(String file_name) {
		execute(file_name);
	}

	public HashMap<String, List<String>> getHashish() {
		return map_author_coauthor;
	}

	public List<String> getList_authors() {
		return list_authors;
	}

	public void setList_authors(List<String> list_authors) {
		this.list_authors = list_authors;
	}

	public List<String> getList_coauthors() {
		return list_coauthors;
	}

	public void setList_coauthors(List<String> list_coauthors) {
		this.list_coauthors = list_coauthors;
	}

	public List getList_years() {
		return list_years;
	}

	public void setList_years(List list_years) {
		this.list_years = list_years;
	}

	public HashMap<String, List<String>> getMap_author_coauthor() {
		return map_author_coauthor;
	}

	public void setMap_author_coauthor(
			HashMap<String, List<String>> map_author_coauthor) {
		this.map_author_coauthor = map_author_coauthor;
	}

	public List get_list_years(String file_name) {
		list_years = new ArrayList();
		String xml_file = getClass().getResource(file_name).toExternalForm();

		String query = "for $x in doc(\"" + xml_file + "\")/dblp "
				+ "return distinct-values($x/*/year)";

		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();

			XQSequence seq = exp.executeQuery(query);

			while (seq.next()) {
				list_years.add(seq.getObject());
			}

			seq.close();
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return list_years;
	}

	// liste d'authors de yearD���but au yearFin
	// contraint: yearFin>yearD���but
	public List get_list_authors_by_years(String file_name, int deb_year,
			int fin_year) {
		list_authors = new ArrayList();
		String xml_file = getClass().getResource(file_name).toExternalForm();

		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();

			for (int y = deb_year; y <= fin_year; y++) {
				String query = "for $x in doc(\"" + xml_file
						+ "\")/dblp/* where $x/year = \"" + y
						+ "\" return distinct-values($x/author)";

				XQSequence seq = exp.executeQuery(query);
				while (seq.next()) {
					list_authors.add(seq.getObject().toString());
				}
				seq.close();
			}
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return list_authors;
	}

	public List get_list_coauthors_by_author_by_years(String file_name,
			String author, int deb_year, int fin_year) {
		list_coauthors = new ArrayList();
		String xml_file = getClass().getResource(file_name).toExternalForm();

		try {
			XQDataSource ds = new SaxonXQDataSource();
			XQConnection conn = ds.getConnection();
			XQExpression exp = conn.createExpression();

			for (int y = deb_year; y <= fin_year; y++) {
				String query = "for $x in doc(\"" + xml_file
						+ "\")/dblp/* where $x/author =\"" + author
						+ "\" and $x/year = \"" + y
						+ "\" return distinct-values($x/author)";

				XQSequence seq = exp.executeQuery(query);

				String tempo;

				while (seq.next()) {
					tempo = seq.getObject().toString();

					if (!tempo.equals(author))
						list_coauthors.add(tempo);
				}

				seq.close();
			}
		} catch (XQException err) {
			System.out.println("Failed as expected: " + err.getMessage());
		}

		return list_coauthors;
	}

	public void execute(String file_name) {

		JFrame frame = new JFrame("Saise Date");

		// prompt the user to enter their name
		int debut = Integer.parseInt(JOptionPane.showInputDialog(frame,
				"Date de d�but?"));
		int fin = Integer.parseInt(JOptionPane.showInputDialog(frame,
				"Date de fin"));

		get_list_authors_by_years(file_name, debut, fin);
		map_author_coauthor = new HashMap<String, List<String>>();

		for (String o : list_authors) {
			get_list_coauthors_by_author_by_years(file_name, o, debut, fin);
			map_author_coauthor.put(o, list_coauthors);
		}

		Set<String> listKeys = map_author_coauthor.keySet();
		Iterator<String> iterator = listKeys.iterator();

		List<String> list_tempo = new ArrayList();

		System.out.println(debut + "-" + fin);

		while (iterator.hasNext()) {
			Object key = iterator.next();

			list_tempo = map_author_coauthor.get(key);

			System.out.print(key + "("
					+ getMap_author_coauthor().get(key).size() + ") => ");

			for (String s : list_tempo) {
				System.out.print(s + "(" + map_author_coauthor.get(s).size()
						+ ") ");
			}
			System.out.println();
		}
		System.out.println();
	}

}
