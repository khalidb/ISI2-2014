package USFinal;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.xml.xquery.XQException;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.JDOMParseException;
import org.jdom2.input.SAXBuilder;

public class GridLayoutDemo extends JFrame {
        /**
         * 
         */
        static String f = null;
        static String filePath;
        private static final long serialVersionUID = 1L;
        static final String gapList[] = { "US #1", "US #2", "US #3", "US #4", "Publication List", "Author List", "Year List" };
        final static int maxGap = 20;
        JComboBox treatmentsComboBox;
        JComboBox verGapComboBox;
        JButton applyButton = new JButton("Generate CSV File");
        GridLayout experimentLayout = new GridLayout(2, 2);

        public GridLayoutDemo(String name) {
                super(name);
                setResizable(false);
        }

        public void initGaps() {
                treatmentsComboBox = new JComboBox(gapList);
                // verGapComboBox = new JComboBox(gapList);
        }

        public void addComponentsToPane(final Container pane) {
                initGaps();
                final JPanel compsToExperiment = new JPanel();
                compsToExperiment.setLayout(experimentLayout);
                JPanel controls = new JPanel();
                controls.setLayout(new GridLayout(2, 3));

                // Set up components preferred size
                JButton fc = new JButton("Browse");
                // JButton b = new JButton("Just fake button");
                Dimension buttonSize = fc.getPreferredSize();
                compsToExperiment.setPreferredSize(new Dimension((int) (buttonSize
                                .getWidth() * 4.5) + maxGap,
                                (int) (buttonSize.getHeight() * 5.5) + maxGap * 4));

                experimentLayout.setHgap(50);
                experimentLayout.setVgap(50);
                experimentLayout.layoutContainer(compsToExperiment);
                // Add buttons to experiment with Grid Layout
                // compsToExperiment.add(fc);
                // compsToExperiment.add(b);
                // compsToExperiment.add(new Label("Fichier XML non valide"));
                // compsToExperiment.add(new JButton("Button 2"));
                // compsToExperiment.add(new JButton("Button 3"));
                // compsToExperiment.add(new JButton("Long-Named Button 4"));
                // compsToExperiment.add(new JButton("5"));
                //
                // Add controls to set up horizontal and vertical gaps
                controls.add(new Label("Treatments :"));
                // controls.add(new Label("Vertical gap:"));
                controls.add(new Label(" "));
                controls.add(treatmentsComboBox);
                // controls.add(verGapComboBox);
                controls.add(fc);
                controls.add(applyButton);
                // String s = "test";

                final JTextField texte1 = new JTextField(
                                "Fichier XML format DBLP valide");
                final JTextField texte2 = new JTextField("Fichier XML non valide");
                System.out.println(treatmentsComboBox.getSelectedItem().toString());
                // compsToExperiment.add(texte);
                treatmentsComboBox.addItemListener(new ItemListener() {
                        @Override
                        public void itemStateChanged(ItemEvent e) {
                                if (e.getStateChange() == ItemEvent.SELECTED) {
                                        JComboBox localCombo = (JComboBox) e.getSource();
                                        System.out.println(localCombo.getSelectedItem().toString());
                                }
                        }
                });

                fc.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent event) {

                                FileChooserBox fcBox = new FileChooserBox();
                                String file = fcBox.getSelectedFile();
                                f = file;
                                System.out.println(file);
                                try {
                                        try {
                                                compsToExperiment.remove(texte1);
                                                compsToExperiment.remove(texte2);
                                        } catch (Exception e) {
                                        }
                                        if (isCorrect(file))
                                                compsToExperiment.add(texte1);
                                        else
                                                compsToExperiment.add(texte2);
                                } catch (NullPointerException e) {
                                        System.out.println("Exception" + file);
                                } catch (FileNotFoundException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                } catch (IOException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                } catch (XQException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                } catch (JDOMParseException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                }
                                compsToExperiment.revalidate();
                                compsToExperiment.repaint();
                        }
                });

                // GENERATION CSV
                applyButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent event) {
                                try {
                                        BufferedWriter fbw = null;
                                        Map<String, List<String>> reponse = new HashMap<String, List<String>>();
                                        f=f.substring(f.lastIndexOf('\\'));
                                        System.out.println(f);
                                        if (!f.equals(null)) {
                                                final JFileChooser fc2 = new JFileChooser();
                                                int returnVal = fc2.showSaveDialog(fc2.getParent()); // parent
                                                                                                                                                                // component
                                                                                                                                                                // to
                                                                                                                                                                // JFileChooser
                                                if (returnVal == JFileChooser.APPROVE_OPTION) {
                                                        File fileToWrite = fc2.getSelectedFile();
                                                        fbw = new BufferedWriter(
                                                                        new FileWriter(fileToWrite));
                                                }

                                                if (treatmentsComboBox.getSelectedItem().toString()
                                                                .equals("US #1")) {
                                                        UserStory1 us1 = new UserStory1(f);
                                                        reponse = us1.getHashish();
                                                } else if (treatmentsComboBox.getSelectedItem()
                                                                .toString().equals("US #2")) {
                                                        UserStory2 us2 = new UserStory2(f);
                                                        reponse = us2.getHashish();
                                                        // us2.execute(f);
                                                        // TRAITEMENT ALIX
                                                } else if (treatmentsComboBox.getSelectedItem()
                                                                .toString().equals("US #3")) {
                                                        UserStory3 us3 = new UserStory3(f);
                                                        reponse = us3.getHashish();
                                                        // us2.execute(f);
                                                        // TRAITEMENT ALIX
                                                } else if (treatmentsComboBox.getSelectedItem()
                                                                .toString().equals("US #4")) {
                                                        UserStory4 us4 = new UserStory4(f);
                                                        reponse = us4.getHashish();

                                                        // us2.execute(f);
                                                        // TRAITEMENT ALIX
                                                }
                                        else if (treatmentsComboBox.getSelectedItem()
                                        		.toString().equals("Publication List")) {
                                        	UserStoryBonus1 usb1 = new UserStoryBonus1(f);
                                        	reponse = usb1.getHashish();
                                        	
                                        	// us2.execute(f);
                                        	// TRAITEMENT ALIX
                                        }
                                 else if (treatmentsComboBox.getSelectedItem()
                                		.toString().equals("Author List")) {
                                	 UserStoryBonus2 usb2 = new UserStoryBonus2(f);
                                	reponse = usb2.getHashish();
                                	
                                	// us2.execute(f);
                                	// TRAITEMENT ALIX
                                
                        } 
                                 else if (treatmentsComboBox.getSelectedItem()
                        		.toString().equals("Year List")) {
                        	UserStoryBonus3 us3 = new UserStoryBonus3(f);
                        	reponse = us3.getHashish();
                        	
                        	// us2.execute(f);
                        	// TRAITEMENT ALIX
                        }

                                                for (Entry<String, List<String>> entry : reponse
                                                                .entrySet()) 
                                                {
//                                                	fbw.write(entry.getKey() + ";");
                                                        for(String s : entry.getValue())
                                                        {
                                                        fbw.write(entry.getKey() + ";"+s+";\n");
                                                        }
                                                        
                                                }
                                                fbw.close();
                                        }
                                else
                                                System.out.println("Aucun choix effectu� ");
                                } catch (NullPointerException e) {
                                	System.out.println("Aucun fichier selectionn� : " + e);}
                                catch (IOException e) {System.out.println("Aucun fichier selectionn� : " + e);}
                        }
                });

                // Process the Apply gaps button press
                // applyButton.addActionListener(new ActionListener(){
                // public void actionPerformed(ActionEvent e){
                // //Get the horizontal gap value
                // String horGap = (String)horGapComboBox.getSelectedItem();
                // //Get the vertical gap value
                // String verGap = (String)verGapComboBox.getSelectedItem();
                // //Set up the horizontal gap value
                // experimentLayout.setHgap(Integer.parseInt(horGap));
                // //Set up the vertical gap value
                // experimentLayout.setVgap(Integer.parseInt(verGap));
                // //Set up the layout of the buttons
                // experimentLayout.layoutContainer(compsToExperiment);
                // }
                // });
                pane.add(compsToExperiment, BorderLayout.NORTH);
                pane.add(new JSeparator(), BorderLayout.CENTER);
                pane.add(controls, BorderLayout.SOUTH);
        }

        /**
         * Create the GUI and show it. For thread safety, this method is invoked
         * from the event dispatch thread.
         */
        private static void createAndShowGUI() {
                // Create and set up the window.
                GridLayoutDemo frame = new GridLayoutDemo("XML File Chooser");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                // Set up the content pane.
                frame.addComponentsToPane(frame.getContentPane());
                // Display the window.
                frame.pack();
                frame.setVisible(true);
        }

        public static void main(String[] args) {
                /* Use an appropriate Look and Feel 
                try {
                        // UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (UnsupportedLookAndFeelException ex) {
                        ex.printStackTrace();
                } catch (IllegalAccessException ex) {
                        ex.printStackTrace();
                } catch (InstantiationException ex) {
                        ex.printStackTrace();
                } catch (ClassNotFoundException ex) {
                        ex.printStackTrace();
                }
                /* Turn off metal's use of bold fonts */
                UIManager.put("swing.boldMetal", Boolean.FALSE);

                // Schedule a job for the event dispatch thread:
                // creating and showing this application's GUI.
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                                createAndShowGUI();
                        }
                });

        }

        // Test validit� XML format DBLP
        public boolean isCorrect(String file_name) throws FileNotFoundException,
                        IOException, XQException, JDOMParseException {
                System.out.println("Test validit� du fichier XML");
                SAXBuilder sxb = new SAXBuilder();
                Document document;
                File f = new File(file_name);
                filePath = f.getAbsolutePath();
                try {
                        // On cr�e un nouveau document JDOM avec en argument le fichier XML
                        // Le parsing est termin�
                        document = sxb.build(f);
                        // On initialise un nouvel �l�ment racine avec l'�l�ment racine du
                        // document.
                        Element racine = document.getRootElement();
                        System.out.println(racine.toString());
                        if (racine.toString().equals("[Element: <dblp/>]")) {
                                System.out.println("OK XML DBLP");
                                return true;
                        }
                } catch (Exception e) {
                        System.out.println("Exception trait�e : " + e);
                        return false;
                }
                return false;
        }

}