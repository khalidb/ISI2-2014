package USFinal;

	import java.io.ObjectInputStream.GetField;
import java.util.*;

	import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;
	public class PublicationList 
	{

	        private List<String> publicationList;
	        
	        public PublicationList(String file_name) {
	                execute(file_name);
	        }

	        public List<String> getPublicationList() {
	                return publicationList;
	        }

	        public List<String> setPublicationList(String file_name) {
//	                publicationList = new ArrayList();
	                String xml_file = getClass().getResource(file_name).toExternalForm();

	                /*String query = "for $x in doc(\"" + xml_file
	        				+ "\")/dblp/* return node-name($x)";
	                */
	                String query = "for $x in doc(\"" + xml_file
                            + "\")/dblp/* return node-name($x)";
	                
	                
	                try {
	                        XQDataSource ds = new SaxonXQDataSource();
	                        XQConnection conn = ds.getConnection();
	                        XQExpression exp = conn.createExpression();

	                        XQSequence seq = exp.executeQuery(query);
	                        
	                        System.out.println(seq.getObject().toString());
	                        
	                        while (seq.next()) 
	                        {
	                        	System.out.println(seq.getObject().toString());
	                        	publicationList.add(seq.getObject().toString());
	                        }
	                        

	                        seq.close();

	                } catch (XQException err) {
	                        System.out.println("Failed as expected: " + err.getMessage());
	                }

	                return publicationList;
	        }
	        public void execute(String file) 
	        {
	                String file_name = file;
	                setPublicationList(file_name);
	                System.out.println();
	        }
	        public static void main(String[] args) 
	        {
	        
                String file_name = "/dblp_1.xml";
                PublicationList p = new PublicationList(file_name);
                System.out.println("end main");
	        }
	}
