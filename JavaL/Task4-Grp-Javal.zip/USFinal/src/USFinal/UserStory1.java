package USFinal;

import java.io.ObjectInputStream.GetField;
import java.util.*;

import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;
import javax.xml.xquery.XQException;
import javax.xml.xquery.XQExpression;
import javax.xml.xquery.XQSequence;

import net.sf.saxon.xqj.SaxonXQDataSource;

public class UserStory1 {
        private List<String> list_authors;
        private List<String> list_coauthors;
        private HashMap<String, List<String>> map_author_coauthor;

        public UserStory1(String file_name) {
                execute(file_name);
        }

        public List<String> getList_authors() {
                return list_authors;
        }

        public HashMap<String, List<String>> getHashish() {
                return map_author_coauthor;
        }

        public void setList_authors(List<String> list_authors) {
                this.list_authors = list_authors;
        }

        public List<String> getList_coauthors() {
                return list_coauthors;
        }

        public void setList_coauthors(List<String> list_coauthors) {
                this.list_coauthors = list_coauthors;
        }

        public HashMap<String, List<String>> getMap_author_coauthor() {
                return map_author_coauthor;
        }

        public void setMap_author_coauthor(
                        HashMap<String, List<String>> map_author_coauthor) {
                this.map_author_coauthor = map_author_coauthor;
        }

        public List get_list_authors(String file_name) {
                list_authors = new ArrayList();
                String xml_file = getClass().getResource(file_name).toExternalForm();

                String query = "for $x in doc(\"" + xml_file
                                + "\")/dblp return distinct-values($x/*/author)";

                try {
                        XQDataSource ds = new SaxonXQDataSource();
                        XQConnection conn = ds.getConnection();
                        XQExpression exp = conn.createExpression();

                        XQSequence seq = exp.executeQuery(query);

                        while (seq.next()) {
                                list_authors.add(seq.getObject().toString());
                        }

                        seq.close();

                } catch (XQException err) {
                        System.out.println("Failed as expected: " + err.getMessage());
                }

                return list_authors;
        }

        public List get_list_coauthors_by_author(String file_name, String author) {
                list_coauthors = new ArrayList();
                String xml_file = getClass().getResource(file_name).toExternalForm();

                String query = "for $x in doc(\"" + xml_file
                                + "\")/dblp/* where $x/author =\"" + author
                                + "\" return distinct-values($x/author)";

                try {
                        XQDataSource ds = new SaxonXQDataSource();
                        XQConnection conn = ds.getConnection();
                        XQExpression exp = conn.createExpression();

                        XQSequence seq = exp.executeQuery(query);

                        String tempo;

                        while (seq.next()) {
                                tempo = seq.getObject().toString();

                                if (!tempo.equals(author))
                                        list_coauthors.add(tempo);
                        }

                        seq.close();

                } catch (XQException err) {
                        System.out.println("Failed as expected: " + err.getMessage());
                }

                return list_coauthors;
        }

        public void execute(String file) {
                // UserStory1 us1 = new UserStory1(file_name);
                String file_name = file;
                map_author_coauthor = new HashMap<String, List<String>>();

                get_list_authors(file_name);

                for (String o : list_authors) {
                        get_list_coauthors_by_author(file_name, o);
                        map_author_coauthor.put(o, list_coauthors);
                }

                Set<String> listKeys = map_author_coauthor.keySet();
                Iterator<String> iterator = listKeys.iterator();

                List<String> list_tempo = new ArrayList();

                while (iterator.hasNext()) {
                        Object key = iterator.next();

                        list_tempo = map_author_coauthor.get(key);

                        System.out.print(key + "("
                                        + getMap_author_coauthor().get(key).size() + ") => ");

                        for (String s : list_tempo) {
                                System.out.print(s + "(" + map_author_coauthor.get(s).size()
                                                + ") ");
                        }
                        System.out.println();
                }
        }
}