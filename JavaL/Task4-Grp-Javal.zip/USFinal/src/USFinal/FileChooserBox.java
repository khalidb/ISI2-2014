package USFinal;



        /* ############################################################################
         * 
         * SelectionFichier.java : utilisation des bo�tes de dialogue de s�lection de
         *                         fichier de Swing.
         *                         
         *                         Notamment, l'exemple num�ro 2 explique comment cr�er
         *                         une bo�te de dialogue qui s'ouvre dans le r�pertoire
         *                         courant, et pas dans le r�pertoire "home" de
         *                         l'utilisateur.
         * 
         * Auteur : Christophe Jacquet, Sup�lec
         * 
         * Historique
         * 2008-07-08  Cr�ation
         * 
         * ############################################################################
         */
         
         
        import java.io.File;
        import java.io.IOException;
         
        import javax.swing.JFileChooser;
         
         
        public class FileChooserBox {
                private String selectedFile = "";
                public FileChooserBox()
                {
                        
                System.out.println("fb");
                
                // Bo�te de s�lection de fichier � partir du r�pertoire courant
                File repertoireCourant = null;
                try {
                    // obtention d'un objet File qui d�signe le r�pertoire courant. Le
                    // "getCanonicalFile" n'est pas absolument n�cessaire mais permet
                    // d'�viter les /Truc/./Chose/ ...
                    repertoireCourant = new File(".").getCanonicalFile();
                    System.out.println("R�pertoire courant : " + repertoireCourant);
                } catch(IOException e) {}
                
                
                // // cr�ation de la bo�te de dialogue dans ce r�pertoire courant
                // (ou dans "home" s'il y a eu une erreur d'entr�e/sortie, auquel
                // cas repertoireCourant vaut null)
                JFileChooser dialogue = new JFileChooser(repertoireCourant);
             
            // affichage
            dialogue.showOpenDialog(null);
             
            // r�cup�ration du fichier s�lectionn�
//            System.out.println("Fichier choisi : " + dialogue.getSelectedFile());
            try{selectedFile = dialogue.getSelectedFile().toString();}
            catch(Exception e){System.out.println("Fichier non trouv� / selectionn�"); selectedFile="";}
                }
                
            public static void main(String[] args) {
                // Exemple num�ro 1
                // Bo�te de s�lection de fichier � partir du r�pertoire
                // "home" de l'utilisateur
                {        
                        FileChooserBox fbc = new FileChooserBox();
                }
                
                         
            }
            
            public String getSelectedFile()
            {return selectedFile;}
        }